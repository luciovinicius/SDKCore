#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class LoginModuleLoginService, LoginModuleRxcommon_coreSingle, LoginModuleOtpSendResponse, LoginModuleOtpValidateResponse, LoginModuleTokenDataChild, LoginModuleKotlinThrowable, LoginModuleRxcommon_coreSingleEmitter, LoginModuleLoginBadResponseChild, LoginModuleLoginCredentialsChild, LoginModuleLoginCredentialsNewPasswordChild, LoginModuleLogoutResponseChild, LoginModulePayLoadJWT, LoginModuleStateLocal, LoginModuleStateResponseLocal, LoginModuleTokenDeRogelio, LoginModuleDeviceDataChild, LoginModuleMetadataQueryUnitChild, LoginModuleGKMACGlobalKitConfiguration, LoginModuleOtpSendRequest, LoginModuleTokenValidation, LoginModuleOtpValidateRequest, LoginModuleToken, LoginModuleRecipient, LoginModuleKotlinByteIterator, LoginModuleKotlinByteArray, LoginModuleRxcommon_coreOnErrorReturn, LoginModuleKotlinArray, LoginModuleRxcommon_coreColdEmitter, LoginModuleKotlinx_serialization_runtimeSerialKind, LoginModuleKotlinNothing, LoginModuleKotlinx_serialization_runtimeUpdateMode, LoginModuleRxcommon_coreOperator, LoginModuleKotlinEnum;

@protocol LoginModuleKotlinx_serialization_runtimeKSerializer, LoginModuleGKMALBDeviceData, LoginModuleGKMALBChangePasswordData, LoginModuleGKMALBConfirmForgotPasswordData, LoginModuleGKMALBCreateDeviceData, LoginModuleGKMALBCreateDeviceResponse, LoginModuleGKMALBCreateUserData, LoginModuleGKMALBCreateUserResponse, LoginModuleGKMALBForgotPasswordData, LoginModuleGKMALBForgotPasswordResponse, LoginModuleGKMALBGOTPTDataRespData, LoginModuleGKMALBGenerateOTPTData, LoginModuleGKMALBGenerateOTPTResponse, LoginModuleRxcommon_coreObserver, LoginModuleGKMALBLoginBadResponse, LoginModuleGKMALBLoginCredentials, LoginModuleGKMALBLoginCredentialsNewPassword, LoginModuleGKMALBLoginResponse, LoginModuleGKMALBLogoutResponse, LoginModuleGKMALBMetadataData, LoginModuleGKMALBMetadataDataResponse, LoginModuleGKMALBMetadataQueryData, LoginModuleGKMALBMetadataQueryUnit, LoginModuleGKMALBMetadataQueryResponse, LoginModuleGKMALBNIPData, LoginModuleGKMALBNIPDataResponse, LoginModuleGKMALBProfileData, LoginModuleGKMALBSendVerificationCodeData, LoginModuleGKMALBSendVerificationCodeDataResponse, LoginModuleGKMALBTokenData, LoginModuleGKMALBVOTPTRespData, LoginModuleGKMALBValidateNIPData, LoginModuleGKMALBValidateNIPDataResponse, LoginModuleGKMALBValidateOTPTData, LoginModuleGKMALBValidateOTPTResponse, LoginModuleKotlinx_serialization_runtimeEncoder, LoginModuleKotlinx_serialization_runtimeSerialDescriptor, LoginModuleKotlinx_serialization_runtimeSerializationStrategy, LoginModuleKotlinx_serialization_runtimeDecoder, LoginModuleKotlinx_serialization_runtimeDeserializationStrategy, LoginModuleGKMALBOTPService, LoginModuleGKMALBValidateAuthenticationDataService, LoginModuleGKMALBAuthenticateService, LoginModuleGKMALBEventBusClientService, LoginModuleGKMALBJWTService, LoginModuleGKMALBTokenManagementService, LoginModuleGKMALBStorageService, LoginModuleGKMALBValidationServiceFactory, LoginModuleRxcommon_coreSource, LoginModuleRxcommon_coreDisposable, LoginModuleRxcommon_coreEmitter, LoginModuleKotlinx_serialization_runtimeCompositeEncoder, LoginModuleKotlinx_serialization_runtimeSerialModule, LoginModuleKotlinAnnotation, LoginModuleKotlinx_serialization_runtimeCompositeDecoder, LoginModuleKotlinIterator, LoginModuleKotlinx_serialization_runtimeSerialModuleCollector, LoginModuleKotlinKClass, LoginModuleKotlinComparable, LoginModuleKotlinKDeclarationContainer, LoginModuleKotlinKAnnotatedElement, LoginModuleKotlinKClassifier;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wnullability"

@interface KotlinBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end;

@interface KotlinBase (KotlinBaseCopying) <NSCopying>
@end;

__attribute__((objc_runtime_name("KotlinMutableSet")))
__attribute__((swift_name("KotlinMutableSet")))
@interface LoginModuleMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end;

__attribute__((objc_runtime_name("KotlinMutableDictionary")))
__attribute__((swift_name("KotlinMutableDictionary")))
@interface LoginModuleMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end;

@interface NSError (NSErrorKotlinException)
@property (readonly) id _Nullable kotlinException;
@end;

__attribute__((objc_runtime_name("KotlinNumber")))
__attribute__((swift_name("KotlinNumber")))
@interface LoginModuleNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end;

__attribute__((objc_runtime_name("KotlinByte")))
__attribute__((swift_name("KotlinByte")))
@interface LoginModuleByte : LoginModuleNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end;

__attribute__((objc_runtime_name("KotlinUByte")))
__attribute__((swift_name("KotlinUByte")))
@interface LoginModuleUByte : LoginModuleNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end;

__attribute__((objc_runtime_name("KotlinShort")))
__attribute__((swift_name("KotlinShort")))
@interface LoginModuleShort : LoginModuleNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end;

__attribute__((objc_runtime_name("KotlinUShort")))
__attribute__((swift_name("KotlinUShort")))
@interface LoginModuleUShort : LoginModuleNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end;

__attribute__((objc_runtime_name("KotlinInt")))
__attribute__((swift_name("KotlinInt")))
@interface LoginModuleInt : LoginModuleNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end;

__attribute__((objc_runtime_name("KotlinUInt")))
__attribute__((swift_name("KotlinUInt")))
@interface LoginModuleUInt : LoginModuleNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end;

__attribute__((objc_runtime_name("KotlinLong")))
__attribute__((swift_name("KotlinLong")))
@interface LoginModuleLong : LoginModuleNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end;

__attribute__((objc_runtime_name("KotlinULong")))
__attribute__((swift_name("KotlinULong")))
@interface LoginModuleULong : LoginModuleNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end;

__attribute__((objc_runtime_name("KotlinFloat")))
__attribute__((swift_name("KotlinFloat")))
@interface LoginModuleFloat : LoginModuleNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end;

__attribute__((objc_runtime_name("KotlinDouble")))
__attribute__((swift_name("KotlinDouble")))
@interface LoginModuleDouble : LoginModuleNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end;

__attribute__((objc_runtime_name("KotlinBoolean")))
__attribute__((swift_name("KotlinBoolean")))
@interface LoginModuleBoolean : LoginModuleNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApplicationConfig")))
@interface LoginModuleApplicationConfig : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)applicationConfig __attribute__((swift_name("init()")));
- (NSString *)getOtpPathPath:(NSString * _Nullable)path __attribute__((swift_name("getOtpPath(path:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginFactory")))
@interface LoginModuleLoginFactory : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loginFactory __attribute__((swift_name("init()")));
- (LoginModuleLoginService *)getLoginService __attribute__((swift_name("getLoginService()")));
- (void)doInitLoginServiceFactory __attribute__((swift_name("doInitLoginServiceFactory()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginService")))
@interface LoginModuleLoginService : KotlinBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LoginModuleRxcommon_coreSingle *)addMetadataToProfileData:(NSString *)data __attribute__((swift_name("addMetadataToProfile(data:)")));
- (LoginModuleRxcommon_coreSingle *)changePasswordData:(NSString *)data __attribute__((swift_name("changePassword(data:)")));
- (LoginModuleRxcommon_coreSingle *)confirmForgotPasswordData:(NSString *)data __attribute__((swift_name("confirmForgotPassword(data:)")));
- (LoginModuleRxcommon_coreSingle *)createDeviceData:(NSString *)data __attribute__((swift_name("createDevice(data:)")));
- (LoginModuleRxcommon_coreSingle *)createNIPData:(NSString *)data __attribute__((swift_name("createNIP(data:)")));
- (LoginModuleRxcommon_coreSingle *)createProfileData:(NSString *)data __attribute__((swift_name("createProfile(data:)")));
- (LoginModuleRxcommon_coreSingle *)createUserData:(NSString *)data __attribute__((swift_name("createUser(data:)")));
- (LoginModuleRxcommon_coreSingle *)forgotPasswordData:(NSString *)data __attribute__((swift_name("forgotPassword(data:)")));
- (LoginModuleRxcommon_coreSingle *)generateOTPTData:(NSString *)data __attribute__((swift_name("generateOTPT(data:)")));
- (LoginModuleRxcommon_coreSingle *)getProfile __attribute__((swift_name("getProfile()")));
- (LoginModuleRxcommon_coreSingle *)getTokenData:(NSString *)data __attribute__((swift_name("getToken(data:)")));
- (LoginModuleRxcommon_coreSingle *)getUserInfo __attribute__((swift_name("getUserInfo()")));
- (LoginModuleRxcommon_coreSingle *)getUserInfoComplete __attribute__((swift_name("getUserInfoComplete()")));
- (LoginModuleRxcommon_coreSingle *)loginData:(NSString *)data __attribute__((swift_name("login(data:)")));
- (LoginModuleRxcommon_coreSingle *)logoutData:(NSString *)data __attribute__((swift_name("logout(data:)")));
- (LoginModuleRxcommon_coreSingle *)queryMetadataFromProfileData:(NSString *)data __attribute__((swift_name("queryMetadataFromProfile(data:)")));
- (LoginModuleRxcommon_coreSingle *)removeToken __attribute__((swift_name("removeToken()")));
- (LoginModuleRxcommon_coreSingle *)sendVerificationCodeData:(NSString *)data __attribute__((swift_name("sendVerificationCode(data:)")));
- (LoginModuleRxcommon_coreSingle *)validateNIPData:(NSString *)data __attribute__((swift_name("validateNIP(data:)")));
- (LoginModuleRxcommon_coreSingle *)validateOTPTData:(NSString *)data __attribute__((swift_name("validateOTPT(data:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpServiceApi")))
@interface LoginModuleOtpServiceApi : KotlinBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)sendOtpMdn:(NSString *)mdn callback:(void (^)(LoginModuleOtpSendResponse * _Nullable, NSString * _Nullable))callback __attribute__((swift_name("sendOtp(mdn:callback:)")));
- (void)validateOtpOtp:(NSString *)otp callback:(void (^)(LoginModuleOtpValidateResponse * _Nullable, NSString * _Nullable))callback __attribute__((swift_name("validateOtp(otp:callback:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BusRequest")))
@interface LoginModuleBusRequest : KotlinBase
- (instancetype)initWithIdState:(NSString *)idState state:(LoginModuleTokenDataChild *)state __attribute__((swift_name("init(idState:state:)"))) __attribute__((objc_designated_initializer));
@property NSString *idState __attribute__((swift_name("idState")));
@property LoginModuleTokenDataChild *state __attribute__((swift_name("state")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BusRequest.Companion")))
@interface LoginModuleBusRequestCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBChangePasswordData")))
@protocol LoginModuleGKMALBChangePasswordData
@required
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property (readonly, getter=doNewPassword) NSString *newPassword __attribute__((swift_name("newPassword")));
@property (readonly) NSString *previousPassword __attribute__((swift_name("previousPassword")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChangePasswordDataChild")))
@interface LoginModuleChangePasswordDataChild : KotlinBase <LoginModuleGKMALBChangePasswordData>
- (instancetype)initWithPreviousPassword:(NSString *)previousPassword newPassword:(NSString *)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("init(previousPassword:newPassword:device:)"))) __attribute__((objc_designated_initializer));
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property (readonly, getter=doNewPassword) NSString *newPassword __attribute__((swift_name("newPassword")));
@property (readonly) NSString *previousPassword __attribute__((swift_name("previousPassword")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChangePasswordDataChild.Companion")))
@interface LoginModuleChangePasswordDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBConfirmForgotPasswordData")))
@protocol LoginModuleGKMALBConfirmForgotPasswordData
@required
@property (readonly) NSString *confirmationCode __attribute__((swift_name("confirmationCode")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfirmForgotPasswordDataChild")))
@interface LoginModuleConfirmForgotPasswordDataChild : KotlinBase <LoginModuleGKMALBConfirmForgotPasswordData>
- (instancetype)initWithUsername:(NSString *)username password:(NSString *)password confirmationCode:(NSString *)confirmationCode __attribute__((swift_name("init(username:password:confirmationCode:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *confirmationCode __attribute__((swift_name("confirmationCode")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfirmForgotPasswordDataChild.Companion")))
@interface LoginModuleConfirmForgotPasswordDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBCreateDeviceData")))
@protocol LoginModuleGKMALBCreateDeviceData
@required
@property (readonly) BOOL active __attribute__((swift_name("active")));
@property (readonly) NSString *deviceId __attribute__((swift_name("deviceId")));
@property (readonly) NSString *keyDokId __attribute__((swift_name("keyDokId")));
@property (readonly) NSString *model __attribute__((swift_name("model")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateDeviceDataChild")))
@interface LoginModuleCreateDeviceDataChild : KotlinBase <LoginModuleGKMALBCreateDeviceData>
- (instancetype)initWithDeviceId:(NSString *)deviceId model:(NSString *)model keyDokId:(NSString *)keyDokId type:(NSString *)type active:(BOOL)active __attribute__((swift_name("init(deviceId:model:keyDokId:type:active:)"))) __attribute__((objc_designated_initializer));
@property BOOL active __attribute__((swift_name("active")));
@property NSString *deviceId __attribute__((swift_name("deviceId")));
@property NSString *keyDokId __attribute__((swift_name("keyDokId")));
@property NSString *model __attribute__((swift_name("model")));
@property NSString *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateDeviceDataChild.Companion")))
@interface LoginModuleCreateDeviceDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBCreateDeviceResponse")))
@protocol LoginModuleGKMALBCreateDeviceResponse
@required
@property (readonly) BOOL active __attribute__((swift_name("active")));
@property (readonly) NSString *deviceTypeId __attribute__((swift_name("deviceTypeId")));
@property (readonly) NSString *deviceTypeKey __attribute__((swift_name("deviceTypeKey")));
@property (readonly) NSString *deviceTypeValue __attribute__((swift_name("deviceTypeValue")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *idKeyDok __attribute__((swift_name("idKeyDok")));
@property (readonly) NSString *keyDokId __attribute__((swift_name("keyDokId")));
@property (readonly) NSString *lid __attribute__((swift_name("lid")));
@property (readonly) NSString *model __attribute__((swift_name("model")));
@property (readonly) NSString *registrationDate __attribute__((swift_name("registrationDate")));
@property (readonly) NSString *transactionId __attribute__((swift_name("transactionId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateDeviceResponseChild")))
@interface LoginModuleCreateDeviceResponseChild : KotlinBase <LoginModuleGKMALBCreateDeviceResponse>
- (instancetype)initWithLid:(NSString *)lid model:(NSString *)model keyDokId:(NSString *)keyDokId deviceTypeKey:(NSString *)deviceTypeKey deviceTypeValue:(NSString *)deviceTypeValue registrationDate:(NSString *)registrationDate active:(BOOL)active transactionId:(NSString *)transactionId id:(NSString *)id idKeyDok:(NSString *)idKeyDok deviceTypeId:(NSString *)deviceTypeId __attribute__((swift_name("init(lid:model:keyDokId:deviceTypeKey:deviceTypeValue:registrationDate:active:transactionId:id:idKeyDok:deviceTypeId:)"))) __attribute__((objc_designated_initializer));
@property (readonly) BOOL active __attribute__((swift_name("active")));
@property (readonly) NSString *deviceTypeId __attribute__((swift_name("deviceTypeId")));
@property (readonly) NSString *deviceTypeKey __attribute__((swift_name("deviceTypeKey")));
@property (readonly) NSString *deviceTypeValue __attribute__((swift_name("deviceTypeValue")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *idKeyDok __attribute__((swift_name("idKeyDok")));
@property (readonly) NSString *keyDokId __attribute__((swift_name("keyDokId")));
@property (readonly) NSString *lid __attribute__((swift_name("lid")));
@property (readonly) NSString *model __attribute__((swift_name("model")));
@property (readonly) NSString *registrationDate __attribute__((swift_name("registrationDate")));
@property (readonly) NSString *transactionId __attribute__((swift_name("transactionId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateDeviceResponseChild.Companion")))
@interface LoginModuleCreateDeviceResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBCreateUserData")))
@protocol LoginModuleGKMALBCreateUserData
@required
@property NSString * _Nullable confirmationCode __attribute__((swift_name("confirmationCode")));
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property NSString * _Nullable emailAddress __attribute__((swift_name("emailAddress")));
@property NSString * _Nullable fathersName __attribute__((swift_name("fathersName")));
@property NSString * _Nullable mothersName __attribute__((swift_name("mothersName")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable terms __attribute__((swift_name("terms")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateUserDataChild")))
@interface LoginModuleCreateUserDataChild : KotlinBase <LoginModuleGKMALBCreateUserData>
- (instancetype)initWithName:(NSString * _Nullable)name fathersName:(NSString * _Nullable)fathersName mothersName:(NSString * _Nullable)mothersName emailAddress:(NSString * _Nullable)emailAddress phoneNumber:(NSString * _Nullable)phoneNumber device:(id<LoginModuleGKMALBDeviceData> _Nullable)device password:(NSString * _Nullable)password username:(NSString * _Nullable)username confirmationCode:(NSString * _Nullable)confirmationCode terms:(NSString * _Nullable)terms __attribute__((swift_name("init(name:fathersName:mothersName:emailAddress:phoneNumber:device:password:username:confirmationCode:terms:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable confirmationCode __attribute__((swift_name("confirmationCode")));
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property NSString * _Nullable emailAddress __attribute__((swift_name("emailAddress")));
@property NSString * _Nullable fathersName __attribute__((swift_name("fathersName")));
@property NSString * _Nullable mothersName __attribute__((swift_name("mothersName")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable terms __attribute__((swift_name("terms")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateUserDataChild.Companion")))
@interface LoginModuleCreateUserDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBCreateUserResponse")))
@protocol LoginModuleGKMALBCreateUserResponse
@required
@property NSString * _Nullable emailAddress __attribute__((swift_name("emailAddress")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable temporalPassword __attribute__((swift_name("temporalPassword")));
@property NSString *userName __attribute__((swift_name("userName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateUserResponseChild")))
@interface LoginModuleCreateUserResponseChild : KotlinBase <LoginModuleGKMALBCreateUserResponse>
- (instancetype)initWithUserName:(NSString *)userName temporalPassword:(NSString * _Nullable)temporalPassword emailAddress:(NSString * _Nullable)emailAddress phoneNumber:(NSString * _Nullable)phoneNumber __attribute__((swift_name("init(userName:temporalPassword:emailAddress:phoneNumber:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable emailAddress __attribute__((swift_name("emailAddress")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable temporalPassword __attribute__((swift_name("temporalPassword")));
@property NSString *userName __attribute__((swift_name("userName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CreateUserResponseChild.Companion")))
@interface LoginModuleCreateUserResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBDeviceData")))
@protocol LoginModuleGKMALBDeviceData
@required
@property NSString * _Nullable appId __attribute__((swift_name("appId")));
@property (readonly) NSString *deviceId __attribute__((swift_name("deviceId")));
@property NSString * _Nullable evidenceId __attribute__((swift_name("evidenceId")));
@property NSString * _Nullable externalId __attribute__((swift_name("externalId")));
@property NSString * _Nullable latitude __attribute__((swift_name("latitude")));
@property NSString * _Nullable longitude __attribute__((swift_name("longitude")));
@property (readonly) NSString *model __attribute__((swift_name("model")));
@property NSString * _Nullable msisdn __attribute__((swift_name("msisdn")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceDataChild")))
@interface LoginModuleDeviceDataChild : KotlinBase <LoginModuleGKMALBDeviceData>
- (instancetype)initWithDeviceId:(NSString *)deviceId model:(NSString *)model type:(NSString *)type appId:(NSString * _Nullable)appId evidenceId:(NSString * _Nullable)evidenceId externalId:(NSString * _Nullable)externalId latitude:(NSString * _Nullable)latitude longitude:(NSString * _Nullable)longitude msisdn:(NSString * _Nullable)msisdn __attribute__((swift_name("init(deviceId:model:type:appId:evidenceId:externalId:latitude:longitude:msisdn:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable appId __attribute__((swift_name("appId")));
@property (readonly) NSString *deviceId __attribute__((swift_name("deviceId")));
@property NSString * _Nullable evidenceId __attribute__((swift_name("evidenceId")));
@property NSString * _Nullable externalId __attribute__((swift_name("externalId")));
@property NSString * _Nullable latitude __attribute__((swift_name("latitude")));
@property NSString * _Nullable longitude __attribute__((swift_name("longitude")));
@property (readonly) NSString *model __attribute__((swift_name("model")));
@property NSString * _Nullable msisdn __attribute__((swift_name("msisdn")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceDataChild.Companion")))
@interface LoginModuleDeviceDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBForgotPasswordData")))
@protocol LoginModuleGKMALBForgotPasswordData
@required
@property NSString * _Nullable answer __attribute__((swift_name("answer")));
@property NSString * _Nullable question __attribute__((swift_name("question")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForgotPasswordDataChid")))
@interface LoginModuleForgotPasswordDataChid : KotlinBase <LoginModuleGKMALBForgotPasswordData>
- (instancetype)initWithUsername:(NSString *)username question:(NSString * _Nullable)question answer:(NSString * _Nullable)answer __attribute__((swift_name("init(username:question:answer:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable answer __attribute__((swift_name("answer")));
@property NSString * _Nullable question __attribute__((swift_name("question")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForgotPasswordDataChid.Companion")))
@interface LoginModuleForgotPasswordDataChidCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBForgotPasswordResponse")))
@protocol LoginModuleGKMALBForgotPasswordResponse
@required
@property NSString * _Nullable deliveryMedium __attribute__((swift_name("deliveryMedium")));
@property NSString * _Nullable destination __attribute__((swift_name("destination")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable question __attribute__((swift_name("question")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForgotPasswordResponseChild")))
@interface LoginModuleForgotPasswordResponseChild : KotlinBase <LoginModuleGKMALBForgotPasswordResponse>
- (instancetype)initWithName:(NSString * _Nullable)name deliveryMedium:(NSString * _Nullable)deliveryMedium destination:(NSString * _Nullable)destination username:(NSString * _Nullable)username question:(NSString * _Nullable)question __attribute__((swift_name("init(name:deliveryMedium:destination:username:question:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable deliveryMedium __attribute__((swift_name("deliveryMedium")));
@property NSString * _Nullable destination __attribute__((swift_name("destination")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable question __attribute__((swift_name("question")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForgotPasswordResponseChild.Companion")))
@interface LoginModuleForgotPasswordResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBGOTPTDataRespData")))
@protocol LoginModuleGKMALBGOTPTDataRespData
@required
@property BOOL isInbursa __attribute__((swift_name("isInbursa")));
@property NSString *ivrPhoneNumber __attribute__((swift_name("ivrPhoneNumber")));
@property NSString *responseCode __attribute__((swift_name("responseCode")));
@property NSString *responseMessage __attribute__((swift_name("responseMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GOTPTDataRespDataChild")))
@interface LoginModuleGOTPTDataRespDataChild : KotlinBase <LoginModuleGKMALBGOTPTDataRespData>
- (instancetype)initWithResponseCode:(NSString *)responseCode responseMessage:(NSString *)responseMessage isInbursa:(BOOL)isInbursa ivrPhoneNumber:(NSString *)ivrPhoneNumber __attribute__((swift_name("init(responseCode:responseMessage:isInbursa:ivrPhoneNumber:)"))) __attribute__((objc_designated_initializer));
@property BOOL isInbursa __attribute__((swift_name("isInbursa")));
@property NSString *ivrPhoneNumber __attribute__((swift_name("ivrPhoneNumber")));
@property NSString *responseCode __attribute__((swift_name("responseCode")));
@property NSString *responseMessage __attribute__((swift_name("responseMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GOTPTDataRespDataChild.Companion")))
@interface LoginModuleGOTPTDataRespDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBGenerateOTPTData")))
@protocol LoginModuleGKMALBGenerateOTPTData
@required
@property NSString *mdn __attribute__((swift_name("mdn")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GenerateOTPTDataChild")))
@interface LoginModuleGenerateOTPTDataChild : KotlinBase <LoginModuleGKMALBGenerateOTPTData>
- (instancetype)initWithMdn:(NSString *)mdn __attribute__((swift_name("init(mdn:)"))) __attribute__((objc_designated_initializer));
@property NSString *mdn __attribute__((swift_name("mdn")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GenerateOTPTDataChild.Companion")))
@interface LoginModuleGenerateOTPTDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBGenerateOTPTResponse")))
@protocol LoginModuleGKMALBGenerateOTPTResponse
@required
@property BOOL isInbursa __attribute__((swift_name("isInbursa")));
@property NSString *ivrPhoneNumber __attribute__((swift_name("ivrPhoneNumber")));
@property NSString *responseCode __attribute__((swift_name("responseCode")));
@property NSString * _Nullable responseMessage __attribute__((swift_name("responseMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GenerateOTPTResponseChild")))
@interface LoginModuleGenerateOTPTResponseChild : KotlinBase <LoginModuleGKMALBGenerateOTPTResponse>
- (instancetype)initWithResponseCode:(NSString *)responseCode responseMessage:(NSString * _Nullable)responseMessage isInbursa:(BOOL)isInbursa ivrPhoneNumber:(NSString *)ivrPhoneNumber __attribute__((swift_name("init(responseCode:responseMessage:isInbursa:ivrPhoneNumber:)"))) __attribute__((objc_designated_initializer));
@property BOOL isInbursa __attribute__((swift_name("isInbursa")));
@property NSString *ivrPhoneNumber __attribute__((swift_name("ivrPhoneNumber")));
@property NSString *responseCode __attribute__((swift_name("responseCode")));
@property NSString * _Nullable responseMessage __attribute__((swift_name("responseMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GenerateOTPTResponseChild.Companion")))
@interface LoginModuleGenerateOTPTResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("Rxcommon_coreObserver")))
@protocol LoginModuleRxcommon_coreObserver
@required
- (void)onComplete __attribute__((swift_name("onComplete()")));
- (void)onErrorThrowable:(LoginModuleKotlinThrowable *)throwable __attribute__((swift_name("onError(throwable:)")));
- (void)onNextValue:(id _Nullable)value __attribute__((swift_name("onNext(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GenerateObserver")))
@interface LoginModuleGenerateObserver : KotlinBase <LoginModuleRxcommon_coreObserver>
- (instancetype)initWithTransactionID:(NSString * _Nullable)transactionID singleEmitter:(LoginModuleRxcommon_coreSingleEmitter *)singleEmitter __attribute__((swift_name("init(transactionID:singleEmitter:)"))) __attribute__((objc_designated_initializer));
- (void)onComplete __attribute__((swift_name("onComplete()")));
- (void)onErrorThrowable:(LoginModuleKotlinThrowable *)throwable __attribute__((swift_name("onError(throwable:)")));
- (void)onNextValue:(id _Nullable)value __attribute__((swift_name("onNext(value:)")));
@property LoginModuleRxcommon_coreSingleEmitter *singleEmitter __attribute__((swift_name("singleEmitter")));
@property NSString * _Nullable transactionID __attribute__((swift_name("transactionID")));
@end;

__attribute__((swift_name("GKMALBLoginBadResponse")))
@protocol LoginModuleGKMALBLoginBadResponse
@required
@property NSString *code __attribute__((swift_name("code")));
@property (getter=description_) NSString * _Nullable description __attribute__((swift_name("description")));
@property NSString * _Nullable error __attribute__((swift_name("error")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginBadResponseChild")))
@interface LoginModuleLoginBadResponseChild : KotlinBase <LoginModuleGKMALBLoginBadResponse>
- (instancetype)initWithCode:(NSString *)code error:(NSString * _Nullable)error description:(NSString * _Nullable)description __attribute__((swift_name("init(code:error:description:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (LoginModuleLoginBadResponseChild *)doCopyCode:(NSString *)code error:(NSString * _Nullable)error description:(NSString * _Nullable)description __attribute__((swift_name("doCopy(code:error:description:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *code __attribute__((swift_name("code")));
@property (getter=description_) NSString * _Nullable description __attribute__((swift_name("description")));
@property NSString * _Nullable error __attribute__((swift_name("error")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginBadResponseChild.Companion")))
@interface LoginModuleLoginBadResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBLoginCredentials")))
@protocol LoginModuleGKMALBLoginCredentials
@required
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property (getter=doNewPassword) NSString * _Nullable newPassword __attribute__((swift_name("newPassword")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginCredentialsChild")))
@interface LoginModuleLoginCredentialsChild : KotlinBase <LoginModuleGKMALBLoginCredentials>
- (instancetype)initWithUsername:(NSString *)username password:(NSString *)password newPassword:(NSString * _Nullable)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("init(username:password:newPassword:device:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (id<LoginModuleGKMALBDeviceData> _Nullable)component4 __attribute__((swift_name("component4()")));
- (LoginModuleLoginCredentialsChild *)doCopyUsername:(NSString *)username password:(NSString *)password newPassword:(NSString * _Nullable)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("doCopy(username:password:newPassword:device:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property (getter=doNewPassword) NSString * _Nullable newPassword __attribute__((swift_name("newPassword")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginCredentialsChild.Companion")))
@interface LoginModuleLoginCredentialsChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBLoginCredentialsNewPassword")))
@protocol LoginModuleGKMALBLoginCredentialsNewPassword
@required
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property (getter=doNewPassword) NSString * _Nullable newPassword __attribute__((swift_name("newPassword")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginCredentialsNewPasswordChild")))
@interface LoginModuleLoginCredentialsNewPasswordChild : KotlinBase <LoginModuleGKMALBLoginCredentialsNewPassword>
- (instancetype)initWithUsername:(NSString *)username password:(NSString *)password newPassword:(NSString * _Nullable)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("init(username:password:newPassword:device:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (id<LoginModuleGKMALBDeviceData> _Nullable)component4 __attribute__((swift_name("component4()")));
- (LoginModuleLoginCredentialsNewPasswordChild *)doCopyUsername:(NSString *)username password:(NSString *)password newPassword:(NSString * _Nullable)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("doCopy(username:password:newPassword:device:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property (getter=doNewPassword) NSString * _Nullable newPassword __attribute__((swift_name("newPassword")));
@property (readonly) NSString *password __attribute__((swift_name("password")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginCredentialsNewPasswordChild.Companion")))
@interface LoginModuleLoginCredentialsNewPasswordChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBLoginResponse")))
@protocol LoginModuleGKMALBLoginResponse
@required
@property (readonly) NSString * _Nullable data __attribute__((swift_name("data")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponseChild")))
@interface LoginModuleLoginResponseChild : KotlinBase <LoginModuleGKMALBLoginResponse>
- (instancetype)initWithStatus:(NSString *)status message:(NSString *)message data:(NSString * _Nullable)data __attribute__((swift_name("init(status:message:data:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString * _Nullable data __attribute__((swift_name("data")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponseChild.Companion")))
@interface LoginModuleLoginResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponseMessage")))
@interface LoginModuleLoginResponseMessage : KotlinBase
- (instancetype)initWithId:(NSString *)id data:(NSString *)data __attribute__((swift_name("init(id:data:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *data __attribute__((swift_name("data")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginResponseMessage.Companion")))
@interface LoginModuleLoginResponseMessageCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBLogoutResponse")))
@protocol LoginModuleGKMALBLogoutResponse
@required
@property BOOL success __attribute__((swift_name("success")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogoutResponseChild")))
@interface LoginModuleLogoutResponseChild : KotlinBase <LoginModuleGKMALBLogoutResponse>
- (instancetype)initWithSuccess:(BOOL)success __attribute__((swift_name("init(success:)"))) __attribute__((objc_designated_initializer));
- (BOOL)component1 __attribute__((swift_name("component1()")));
- (LoginModuleLogoutResponseChild *)doCopySuccess:(BOOL)success __attribute__((swift_name("doCopy(success:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property BOOL success __attribute__((swift_name("success")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogoutResponseChild.Companion")))
@interface LoginModuleLogoutResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBMetadataData")))
@protocol LoginModuleGKMALBMetadataData
@required
@property NSString *key __attribute__((swift_name("key")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@property NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataDataChild")))
@interface LoginModuleMetadataDataChild : KotlinBase <LoginModuleGKMALBMetadataData>
- (instancetype)initWithUsername:(NSString * _Nullable)username key:(NSString *)key value:(NSString *)value __attribute__((swift_name("init(username:key:value:)"))) __attribute__((objc_designated_initializer));
@property NSString *key __attribute__((swift_name("key")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@property NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataDataChild.Companion")))
@interface LoginModuleMetadataDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBMetadataDataResponse")))
@protocol LoginModuleGKMALBMetadataDataResponse
@required
@property BOOL active __attribute__((swift_name("active")));
@property NSString *id __attribute__((swift_name("id")));
@property NSString *idKeyDok __attribute__((swift_name("idKeyDok")));
@property NSString *key __attribute__((swift_name("key")));
@property NSString *keyDokId __attribute__((swift_name("keyDokId")));
@property NSString *transactionId __attribute__((swift_name("transactionId")));
@property NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataDataResponseChild")))
@interface LoginModuleMetadataDataResponseChild : KotlinBase <LoginModuleGKMALBMetadataDataResponse>
- (instancetype)initWithKey:(NSString *)key value:(NSString *)value active:(BOOL)active transactionId:(NSString *)transactionId idKeyDok:(NSString *)idKeyDok keyDokId:(NSString *)keyDokId id:(NSString *)id __attribute__((swift_name("init(key:value:active:transactionId:idKeyDok:keyDokId:id:)"))) __attribute__((objc_designated_initializer));
@property BOOL active __attribute__((swift_name("active")));
@property NSString *id __attribute__((swift_name("id")));
@property NSString *idKeyDok __attribute__((swift_name("idKeyDok")));
@property NSString *key __attribute__((swift_name("key")));
@property NSString *keyDokId __attribute__((swift_name("keyDokId")));
@property NSString *transactionId __attribute__((swift_name("transactionId")));
@property NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataDataResponseChild.Companion")))
@interface LoginModuleMetadataDataResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBMetadataQueryData")))
@protocol LoginModuleGKMALBMetadataQueryData
@required
@property (readonly) NSString * _Nullable key __attribute__((swift_name("key")));
@property (readonly) NSString * _Nullable keyDokId __attribute__((swift_name("keyDokId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataQueryDataChild")))
@interface LoginModuleMetadataQueryDataChild : KotlinBase <LoginModuleGKMALBMetadataQueryData>
- (instancetype)initWithKeyDokId:(NSString * _Nullable)keyDokId key:(NSString * _Nullable)key __attribute__((swift_name("init(keyDokId:key:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable key __attribute__((swift_name("key")));
@property NSString * _Nullable keyDokId __attribute__((swift_name("keyDokId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataQueryDataChild.Companion")))
@interface LoginModuleMetadataQueryDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBMetadataQueryResponse")))
@protocol LoginModuleGKMALBMetadataQueryResponse
@required
@property NSArray<id<LoginModuleGKMALBMetadataQueryUnit>> *data __attribute__((swift_name("data")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataQueryResponseChild")))
@interface LoginModuleMetadataQueryResponseChild : KotlinBase <LoginModuleGKMALBMetadataQueryResponse>
- (instancetype)initWithData:(NSArray<id<LoginModuleGKMALBMetadataQueryUnit>> *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property NSArray<id<LoginModuleGKMALBMetadataQueryUnit>> *data __attribute__((swift_name("data")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataQueryResponseChild.Companion")))
@interface LoginModuleMetadataQueryResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBMetadataQueryUnit")))
@protocol LoginModuleGKMALBMetadataQueryUnit
@required
@property NSString *key __attribute__((swift_name("key")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataQueryUnitChild")))
@interface LoginModuleMetadataQueryUnitChild : KotlinBase <LoginModuleGKMALBMetadataQueryUnit>
- (instancetype)initWithKey:(NSString *)key value:(NSString * _Nullable)value __attribute__((swift_name("init(key:value:)"))) __attribute__((objc_designated_initializer));
@property NSString *key __attribute__((swift_name("key")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataQueryUnitChild.Companion")))
@interface LoginModuleMetadataQueryUnitChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBNIPData")))
@protocol LoginModuleGKMALBNIPData
@required
@property NSString * _Nullable userName __attribute__((swift_name("userName")));
@property NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NIPDataChild")))
@interface LoginModuleNIPDataChild : KotlinBase <LoginModuleGKMALBNIPData>
- (instancetype)initWithUserName:(NSString * _Nullable)userName value:(NSString *)value __attribute__((swift_name("init(userName:value:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable userName __attribute__((swift_name("userName")));
@property NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NIPDataChild.Companion")))
@interface LoginModuleNIPDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBNIPDataResponse")))
@protocol LoginModuleGKMALBNIPDataResponse
@required
@property NSString * _Nullable data __attribute__((swift_name("data")));
@property NSString *message __attribute__((swift_name("message")));
@property NSString *status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NIPDataResponseChild")))
@interface LoginModuleNIPDataResponseChild : KotlinBase <LoginModuleGKMALBNIPDataResponse>
- (instancetype)initWithStatus:(NSString *)status message:(NSString *)message data:(NSString * _Nullable)data __attribute__((swift_name("init(status:message:data:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable data __attribute__((swift_name("data")));
@property NSString *message __attribute__((swift_name("message")));
@property NSString *status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NIPDataResponseChild.Companion")))
@interface LoginModuleNIPDataResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PayLoadJWT")))
@interface LoginModulePayLoadJWT : KotlinBase
- (instancetype)initWithAuthTime:(int32_t)authTime exp:(int32_t)exp username:(NSString *)username __attribute__((swift_name("init(authTime:exp:username:)"))) __attribute__((objc_designated_initializer));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (LoginModulePayLoadJWT *)doCopyAuthTime:(int32_t)authTime exp:(int32_t)exp username:(NSString *)username __attribute__((swift_name("doCopy(authTime:exp:username:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t authTime __attribute__((swift_name("authTime")));
@property (readonly) int32_t exp __attribute__((swift_name("exp")));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PayLoadJWT.Companion")))
@interface LoginModulePayLoadJWTCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBProfileData")))
@protocol LoginModuleGKMALBProfileData
@required
@property NSString * _Nullable accountHolderId __attribute__((swift_name("accountHolderId")));
@property NSString * _Nullable accountId __attribute__((swift_name("accountId")));
@property NSString * _Nullable alias __attribute__((swift_name("alias")));
@property NSString * _Nullable answer __attribute__((swift_name("answer")));
@property LoginModuleLong * _Nullable birthDate __attribute__((swift_name("birthDate")));
@property NSString * _Nullable birthPlace __attribute__((swift_name("birthPlace")));
@property NSString * _Nullable birthPlaceId __attribute__((swift_name("birthPlaceId")));
@property NSString * _Nullable city __attribute__((swift_name("city")));
@property NSString * _Nullable cityId __attribute__((swift_name("cityId")));
@property NSString * _Nullable country __attribute__((swift_name("country")));
@property NSString * _Nullable countryId __attribute__((swift_name("countryId")));
@property LoginModuleLong * _Nullable creationDate __attribute__((swift_name("creationDate")));
@property NSString * _Nullable curp __attribute__((swift_name("curp")));
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable externalIdentifier __attribute__((swift_name("externalIdentifier")));
@property NSString * _Nullable externalNumber __attribute__((swift_name("externalNumber")));
@property NSString * _Nullable fathersName __attribute__((swift_name("fathersName")));
@property NSString * _Nullable genderKey __attribute__((swift_name("genderKey")));
@property NSString * _Nullable gendervalue __attribute__((swift_name("gendervalue")));
@property NSString * _Nullable ine __attribute__((swift_name("ine")));
@property NSString * _Nullable instabug __attribute__((swift_name("instabug")));
@property NSString * _Nullable internalNumber __attribute__((swift_name("internalNumber")));
@property NSString * _Nullable keyDokId __attribute__((swift_name("keyDokId")));
@property NSString * _Nullable mobilePhone __attribute__((swift_name("mobilePhone")));
@property NSString * _Nullable mothersName __attribute__((swift_name("mothersName")));
@property NSString * _Nullable msisdn __attribute__((swift_name("msisdn")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable neighborhood __attribute__((swift_name("neighborhood")));
@property NSString * _Nullable neighborhoodId __attribute__((swift_name("neighborhoodId")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable postalCode __attribute__((swift_name("postalCode")));
@property NSString * _Nullable profileImage __attribute__((swift_name("profileImage")));
@property NSString * _Nullable question __attribute__((swift_name("question")));
@property NSString * _Nullable rfc __attribute__((swift_name("rfc")));
@property NSString * _Nullable secondName __attribute__((swift_name("secondName")));
@property NSString * _Nullable state __attribute__((swift_name("state")));
@property NSString * _Nullable stateId __attribute__((swift_name("stateId")));
@property NSString * _Nullable street __attribute__((swift_name("street")));
@property NSString * _Nullable taxId __attribute__((swift_name("taxId")));
@property NSString * _Nullable taxIdentifier __attribute__((swift_name("taxIdentifier")));
@property LoginModuleBoolean * _Nullable terms __attribute__((swift_name("terms")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ProfileDataChild")))
@interface LoginModuleProfileDataChild : KotlinBase <LoginModuleGKMALBProfileData>
- (instancetype)initWithUsername:(NSString * _Nullable)username mothersName:(NSString * _Nullable)mothersName name:(NSString * _Nullable)name secondName:(NSString * _Nullable)secondName fathersName:(NSString * _Nullable)fathersName genderKey:(NSString * _Nullable)genderKey gendervalue:(NSString * _Nullable)gendervalue rfc:(NSString * _Nullable)rfc curp:(NSString * _Nullable)curp ine:(NSString * _Nullable)ine street:(NSString * _Nullable)street externalNumber:(NSString * _Nullable)externalNumber internalNumber:(NSString * _Nullable)internalNumber neighborhoodId:(NSString * _Nullable)neighborhoodId neighborhood:(NSString * _Nullable)neighborhood cityId:(NSString * _Nullable)cityId city:(NSString * _Nullable)city postalCode:(NSString * _Nullable)postalCode stateId:(NSString * _Nullable)stateId state:(NSString * _Nullable)state country:(NSString * _Nullable)country birthDate:(LoginModuleLong * _Nullable)birthDate birthPlaceId:(NSString * _Nullable)birthPlaceId birthPlace:(NSString * _Nullable)birthPlace terms:(LoginModuleBoolean * _Nullable)terms email:(NSString * _Nullable)email msisdn:(NSString * _Nullable)msisdn device:(id<LoginModuleGKMALBDeviceData> _Nullable)device keyDokId:(NSString * _Nullable)keyDokId alias:(NSString * _Nullable)alias profileImage:(NSString * _Nullable)profileImage question:(NSString * _Nullable)question answer:(NSString * _Nullable)answer creationDate:(LoginModuleLong * _Nullable)creationDate instabug:(NSString * _Nullable)instabug externalIdentifier:(NSString * _Nullable)externalIdentifier accountHolderId:(NSString * _Nullable)accountHolderId accountId:(NSString * _Nullable)accountId taxIdentifier:(NSString * _Nullable)taxIdentifier taxId:(NSString * _Nullable)taxId countryId:(NSString * _Nullable)countryId mobilePhone:(NSString * _Nullable)mobilePhone phoneNumber:(NSString * _Nullable)phoneNumber __attribute__((swift_name("init(username:mothersName:name:secondName:fathersName:genderKey:gendervalue:rfc:curp:ine:street:externalNumber:internalNumber:neighborhoodId:neighborhood:cityId:city:postalCode:stateId:state:country:birthDate:birthPlaceId:birthPlace:terms:email:msisdn:device:keyDokId:alias:profileImage:question:answer:creationDate:instabug:externalIdentifier:accountHolderId:accountId:taxIdentifier:taxId:countryId:mobilePhone:phoneNumber:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable accountHolderId __attribute__((swift_name("accountHolderId")));
@property NSString * _Nullable accountId __attribute__((swift_name("accountId")));
@property NSString * _Nullable alias __attribute__((swift_name("alias")));
@property NSString * _Nullable answer __attribute__((swift_name("answer")));
@property LoginModuleLong * _Nullable birthDate __attribute__((swift_name("birthDate")));
@property NSString * _Nullable birthPlace __attribute__((swift_name("birthPlace")));
@property NSString * _Nullable birthPlaceId __attribute__((swift_name("birthPlaceId")));
@property NSString * _Nullable city __attribute__((swift_name("city")));
@property NSString * _Nullable cityId __attribute__((swift_name("cityId")));
@property NSString * _Nullable country __attribute__((swift_name("country")));
@property NSString * _Nullable countryId __attribute__((swift_name("countryId")));
@property LoginModuleLong * _Nullable creationDate __attribute__((swift_name("creationDate")));
@property NSString * _Nullable curp __attribute__((swift_name("curp")));
@property id<LoginModuleGKMALBDeviceData> _Nullable device __attribute__((swift_name("device")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable externalIdentifier __attribute__((swift_name("externalIdentifier")));
@property NSString * _Nullable externalNumber __attribute__((swift_name("externalNumber")));
@property NSString * _Nullable fathersName __attribute__((swift_name("fathersName")));
@property NSString * _Nullable genderKey __attribute__((swift_name("genderKey")));
@property NSString * _Nullable gendervalue __attribute__((swift_name("gendervalue")));
@property NSString * _Nullable ine __attribute__((swift_name("ine")));
@property NSString * _Nullable instabug __attribute__((swift_name("instabug")));
@property NSString * _Nullable internalNumber __attribute__((swift_name("internalNumber")));
@property NSString * _Nullable keyDokId __attribute__((swift_name("keyDokId")));
@property NSString * _Nullable mobilePhone __attribute__((swift_name("mobilePhone")));
@property NSString * _Nullable mothersName __attribute__((swift_name("mothersName")));
@property NSString * _Nullable msisdn __attribute__((swift_name("msisdn")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable neighborhood __attribute__((swift_name("neighborhood")));
@property NSString * _Nullable neighborhoodId __attribute__((swift_name("neighborhoodId")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable postalCode __attribute__((swift_name("postalCode")));
@property NSString * _Nullable profileImage __attribute__((swift_name("profileImage")));
@property NSString * _Nullable question __attribute__((swift_name("question")));
@property NSString * _Nullable rfc __attribute__((swift_name("rfc")));
@property NSString * _Nullable secondName __attribute__((swift_name("secondName")));
@property NSString * _Nullable state __attribute__((swift_name("state")));
@property NSString * _Nullable stateId __attribute__((swift_name("stateId")));
@property NSString * _Nullable street __attribute__((swift_name("street")));
@property NSString * _Nullable taxId __attribute__((swift_name("taxId")));
@property NSString * _Nullable taxIdentifier __attribute__((swift_name("taxIdentifier")));
@property LoginModuleBoolean * _Nullable terms __attribute__((swift_name("terms")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ProfileDataChild.Companion")))
@interface LoginModuleProfileDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBSendVerificationCodeData")))
@protocol LoginModuleGKMALBSendVerificationCodeData
@required
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SendVerificationCodeDataChild")))
@interface LoginModuleSendVerificationCodeDataChild : KotlinBase <LoginModuleGKMALBSendVerificationCodeData>
- (instancetype)initWithUsername:(NSString *)username __attribute__((swift_name("init(username:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SendVerificationCodeDataChild.Companion")))
@interface LoginModuleSendVerificationCodeDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBSendVerificationCodeDataResponse")))
@protocol LoginModuleGKMALBSendVerificationCodeDataResponse
@required
@property NSString *attributeName __attribute__((swift_name("attributeName")));
@property NSString *deliveryMedium __attribute__((swift_name("deliveryMedium")));
@property NSString *destination __attribute__((swift_name("destination")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SendVerificationCodeDataResponseChild")))
@interface LoginModuleSendVerificationCodeDataResponseChild : KotlinBase <LoginModuleGKMALBSendVerificationCodeDataResponse>
- (instancetype)initWithAttributeName:(NSString *)attributeName deliveryMedium:(NSString *)deliveryMedium destination:(NSString *)destination __attribute__((swift_name("init(attributeName:deliveryMedium:destination:)"))) __attribute__((objc_designated_initializer));
@property NSString *attributeName __attribute__((swift_name("attributeName")));
@property NSString *deliveryMedium __attribute__((swift_name("deliveryMedium")));
@property NSString *destination __attribute__((swift_name("destination")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SendVerificationCodeDataResponseChild.Companion")))
@interface LoginModuleSendVerificationCodeDataResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateLocal")))
@interface LoginModuleStateLocal : KotlinBase
- (instancetype)initWithIdState:(NSString *)idState state:(NSString * _Nullable)state __attribute__((swift_name("init(idState:state:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (LoginModuleStateLocal *)doCopyIdState:(NSString *)idState state:(NSString * _Nullable)state __attribute__((swift_name("doCopy(idState:state:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *idState __attribute__((swift_name("idState")));
@property NSString * _Nullable state __attribute__((swift_name("state")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateLocal.Companion")))
@interface LoginModuleStateLocalCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateResponseLocal")))
@interface LoginModuleStateResponseLocal : KotlinBase
- (instancetype)initWithId:(NSString *)id data:(NSString *)data __attribute__((swift_name("init(id:data:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (LoginModuleStateResponseLocal *)doCopyId:(NSString *)id data:(NSString *)data __attribute__((swift_name("doCopy(id:data:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *data __attribute__((swift_name("data")));
@property NSString *id __attribute__((swift_name("id")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateResponseLocal.Companion")))
@interface LoginModuleStateResponseLocalCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBTokenData")))
@protocol LoginModuleGKMALBTokenData
@required
@property NSString *accessToken __attribute__((swift_name("accessToken")));
@property int32_t expiresIn __attribute__((swift_name("expiresIn")));
@property NSString *idToken __attribute__((swift_name("idToken")));
@property NSString * _Nullable refreshToken __attribute__((swift_name("refreshToken")));
@property NSString *tokenType __attribute__((swift_name("tokenType")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenDataChild")))
@interface LoginModuleTokenDataChild : KotlinBase <LoginModuleGKMALBTokenData>
- (instancetype)initWithAccessToken:(NSString *)accessToken expiresIn:(int32_t)expiresIn idToken:(NSString *)idToken refreshToken:(NSString * _Nullable)refreshToken tokenType:(NSString *)tokenType __attribute__((swift_name("init(accessToken:expiresIn:idToken:refreshToken:tokenType:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (LoginModuleTokenDataChild *)doCopyAccessToken:(NSString *)accessToken expiresIn:(int32_t)expiresIn idToken:(NSString *)idToken refreshToken:(NSString * _Nullable)refreshToken tokenType:(NSString *)tokenType __attribute__((swift_name("doCopy(accessToken:expiresIn:idToken:refreshToken:tokenType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *accessToken __attribute__((swift_name("accessToken")));
@property int32_t expiresIn __attribute__((swift_name("expiresIn")));
@property NSString *idToken __attribute__((swift_name("idToken")));
@property NSString * _Nullable refreshToken __attribute__((swift_name("refreshToken")));
@property NSString *tokenType __attribute__((swift_name("tokenType")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenDataChild.Companion")))
@interface LoginModuleTokenDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenDeRogelio")))
@interface LoginModuleTokenDeRogelio : KotlinBase
- (instancetype)initWithIdState:(NSString *)idState state:(NSString *)state __attribute__((swift_name("init(idState:state:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (LoginModuleTokenDeRogelio *)doCopyIdState:(NSString *)idState state:(NSString *)state __attribute__((swift_name("doCopy(idState:state:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *idState __attribute__((swift_name("idState")));
@property (readonly) NSString *state __attribute__((swift_name("state")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenDeRogelio.Companion")))
@interface LoginModuleTokenDeRogelioCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserInfoGetKeyDokId")))
@interface LoginModuleUserInfoGetKeyDokId : KotlinBase
- (instancetype)initWithKeyDokId:(NSString *)keyDokId __attribute__((swift_name("init(keyDokId:)"))) __attribute__((objc_designated_initializer));
@property NSString *keyDokId __attribute__((swift_name("keyDokId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserInfoGetKeyDokId.Companion")))
@interface LoginModuleUserInfoGetKeyDokIdCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserInfoResponseLocal")))
@interface LoginModuleUserInfoResponseLocal : KotlinBase
- (instancetype)initWithUsername:(NSString * _Nullable)username mothersName:(NSString * _Nullable)mothersName name:(NSString * _Nullable)name secondName:(NSString * _Nullable)secondName fathersName:(NSString * _Nullable)fathersName genderKey:(NSString * _Nullable)genderKey gendervalue:(NSString * _Nullable)gendervalue rfc:(NSString * _Nullable)rfc curp:(NSString * _Nullable)curp ine:(NSString * _Nullable)ine street:(NSString * _Nullable)street externalNumber:(NSString * _Nullable)externalNumber internalNumber:(NSString * _Nullable)internalNumber neighborhoodId:(NSString * _Nullable)neighborhoodId neighborhood:(NSString * _Nullable)neighborhood cityId:(NSString * _Nullable)cityId city:(NSString * _Nullable)city postalCode:(NSString * _Nullable)postalCode stateId:(NSString * _Nullable)stateId state:(NSString * _Nullable)state country:(NSString * _Nullable)country birthDate:(LoginModuleLong * _Nullable)birthDate birthPlace:(NSString * _Nullable)birthPlace email:(NSString * _Nullable)email msisdn:(NSString * _Nullable)msisdn alias:(NSString * _Nullable)alias profileImage:(NSString * _Nullable)profileImage question:(NSString * _Nullable)question creationDate:(LoginModuleLong * _Nullable)creationDate instabug:(NSString *)instabug __attribute__((swift_name("init(username:mothersName:name:secondName:fathersName:genderKey:gendervalue:rfc:curp:ine:street:externalNumber:internalNumber:neighborhoodId:neighborhood:cityId:city:postalCode:stateId:state:country:birthDate:birthPlace:email:msisdn:alias:profileImage:question:creationDate:instabug:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable alias __attribute__((swift_name("alias")));
@property LoginModuleLong * _Nullable birthDate __attribute__((swift_name("birthDate")));
@property NSString * _Nullable birthPlace __attribute__((swift_name("birthPlace")));
@property NSString * _Nullable city __attribute__((swift_name("city")));
@property NSString * _Nullable cityId __attribute__((swift_name("cityId")));
@property NSString * _Nullable country __attribute__((swift_name("country")));
@property LoginModuleLong * _Nullable creationDate __attribute__((swift_name("creationDate")));
@property NSString * _Nullable curp __attribute__((swift_name("curp")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable externalNumber __attribute__((swift_name("externalNumber")));
@property NSString * _Nullable fathersName __attribute__((swift_name("fathersName")));
@property NSString * _Nullable genderKey __attribute__((swift_name("genderKey")));
@property NSString * _Nullable gendervalue __attribute__((swift_name("gendervalue")));
@property NSString * _Nullable ine __attribute__((swift_name("ine")));
@property NSString *instabug __attribute__((swift_name("instabug")));
@property NSString * _Nullable internalNumber __attribute__((swift_name("internalNumber")));
@property NSString * _Nullable mothersName __attribute__((swift_name("mothersName")));
@property NSString * _Nullable msisdn __attribute__((swift_name("msisdn")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable neighborhood __attribute__((swift_name("neighborhood")));
@property NSString * _Nullable neighborhoodId __attribute__((swift_name("neighborhoodId")));
@property NSString * _Nullable postalCode __attribute__((swift_name("postalCode")));
@property NSString * _Nullable profileImage __attribute__((swift_name("profileImage")));
@property NSString * _Nullable question __attribute__((swift_name("question")));
@property NSString * _Nullable rfc __attribute__((swift_name("rfc")));
@property NSString * _Nullable secondName __attribute__((swift_name("secondName")));
@property NSString * _Nullable state __attribute__((swift_name("state")));
@property NSString * _Nullable stateId __attribute__((swift_name("stateId")));
@property NSString * _Nullable street __attribute__((swift_name("street")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserInfoResponseLocal.Companion")))
@interface LoginModuleUserInfoResponseLocalCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBVOTPTRespData")))
@protocol LoginModuleGKMALBVOTPTRespData
@required
@property NSString *responseCode __attribute__((swift_name("responseCode")));
@property NSString *responseMessage __attribute__((swift_name("responseMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VOTPTRespDataChild")))
@interface LoginModuleVOTPTRespDataChild : KotlinBase <LoginModuleGKMALBVOTPTRespData>
- (instancetype)initWithResponseCode:(NSString *)responseCode responseMessage:(NSString *)responseMessage __attribute__((swift_name("init(responseCode:responseMessage:)"))) __attribute__((objc_designated_initializer));
@property NSString *responseCode __attribute__((swift_name("responseCode")));
@property NSString *responseMessage __attribute__((swift_name("responseMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("VOTPTRespDataChild.Companion")))
@interface LoginModuleVOTPTRespDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidNipLocalResponse")))
@interface LoginModuleValidNipLocalResponse : KotlinBase
- (instancetype)initWithSuccess:(BOOL)success __attribute__((swift_name("init(success:)"))) __attribute__((objc_designated_initializer));
@property BOOL success __attribute__((swift_name("success")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidNipLocalResponse.Companion")))
@interface LoginModuleValidNipLocalResponseCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBValidateNIPData")))
@protocol LoginModuleGKMALBValidateNIPData
@required
@property NSString * _Nullable userName __attribute__((swift_name("userName")));
@property NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidateNIPDataChild")))
@interface LoginModuleValidateNIPDataChild : KotlinBase <LoginModuleGKMALBValidateNIPData>
- (instancetype)initWithUserName:(NSString * _Nullable)userName value:(NSString *)value __attribute__((swift_name("init(userName:value:)"))) __attribute__((objc_designated_initializer));
@property NSString * _Nullable userName __attribute__((swift_name("userName")));
@property NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidateNIPDataChild.Companion")))
@interface LoginModuleValidateNIPDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBValidateNIPDataResponse")))
@protocol LoginModuleGKMALBValidateNIPDataResponse
@required
@property BOOL isValid __attribute__((swift_name("isValid")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidateNIPDataResponseChild")))
@interface LoginModuleValidateNIPDataResponseChild : KotlinBase <LoginModuleGKMALBValidateNIPDataResponse>
- (instancetype)initWithIsValid:(BOOL)isValid __attribute__((swift_name("init(isValid:)"))) __attribute__((objc_designated_initializer));
@property BOOL isValid __attribute__((swift_name("isValid")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidateNIPDataResponseChild.Companion")))
@interface LoginModuleValidateNIPDataResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBValidateOTPTData")))
@protocol LoginModuleGKMALBValidateOTPTData
@required
@property NSString *mdn __attribute__((swift_name("mdn")));
@property NSString *otp __attribute__((swift_name("otp")));
@property NSString * _Nullable userName __attribute__((swift_name("userName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidateOTPTDataChild")))
@interface LoginModuleValidateOTPTDataChild : KotlinBase <LoginModuleGKMALBValidateOTPTData>
- (instancetype)initWithMdn:(NSString *)mdn otp:(NSString *)otp userName:(NSString * _Nullable)userName __attribute__((swift_name("init(mdn:otp:userName:)"))) __attribute__((objc_designated_initializer));
@property NSString *mdn __attribute__((swift_name("mdn")));
@property NSString *otp __attribute__((swift_name("otp")));
@property NSString * _Nullable userName __attribute__((swift_name("userName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidateOTPTDataChild.Companion")))
@interface LoginModuleValidateOTPTDataChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("GKMALBValidateOTPTResponse")))
@protocol LoginModuleGKMALBValidateOTPTResponse
@required
@property BOOL isOtpValid __attribute__((swift_name("isOtpValid")));
@property NSString *responseCode __attribute__((swift_name("responseCode")));
@property NSString * _Nullable responseMessage __attribute__((swift_name("responseMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidateOTPTResponseChild")))
@interface LoginModuleValidateOTPTResponseChild : KotlinBase <LoginModuleGKMALBValidateOTPTResponse>
- (instancetype)initWithResponseCode:(NSString *)responseCode responseMessage:(NSString * _Nullable)responseMessage isOtpValid:(BOOL)isOtpValid __attribute__((swift_name("init(responseCode:responseMessage:isOtpValid:)"))) __attribute__((objc_designated_initializer));
@property BOOL isOtpValid __attribute__((swift_name("isOtpValid")));
@property NSString *responseCode __attribute__((swift_name("responseCode")));
@property NSString * _Nullable responseMessage __attribute__((swift_name("responseMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidateOTPTResponseChild.Companion")))
@interface LoginModuleValidateOTPTResponseChildCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerializationStrategy")))
@protocol LoginModuleKotlinx_serialization_runtimeSerializationStrategy
@required
- (void)serializeEncoder:(id<LoginModuleKotlinx_serialization_runtimeEncoder>)encoder obj:(id _Nullable)obj __attribute__((swift_name("serialize(encoder:obj:)")));
@property (readonly) id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDeserializationStrategy")))
@protocol LoginModuleKotlinx_serialization_runtimeDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<LoginModuleKotlinx_serialization_runtimeDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (id _Nullable)patchDecoder:(id<LoginModuleKotlinx_serialization_runtimeDecoder>)decoder old:(id _Nullable)old __attribute__((swift_name("patch(decoder:old:)")));
@property (readonly) id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeKSerializer")))
@protocol LoginModuleKotlinx_serialization_runtimeKSerializer <LoginModuleKotlinx_serialization_runtimeSerializationStrategy, LoginModuleKotlinx_serialization_runtimeDeserializationStrategy>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceDataChildSerializer")))
@interface LoginModuleDeviceDataChildSerializer : KotlinBase <LoginModuleKotlinx_serialization_runtimeKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)deviceDataChildSerializer __attribute__((swift_name("init()")));
- (LoginModuleDeviceDataChild *)deserializeDecoder:(id<LoginModuleKotlinx_serialization_runtimeDecoder>)input __attribute__((swift_name("deserialize(decoder:)")));
- (LoginModuleDeviceDataChild *)patchDecoder:(id<LoginModuleKotlinx_serialization_runtimeDecoder>)decoder old:(LoginModuleDeviceDataChild *)old __attribute__((swift_name("patch(decoder:old:)")));
- (void)serializeEncoder:(id<LoginModuleKotlinx_serialization_runtimeEncoder>)output obj:(LoginModuleDeviceDataChild *)obj __attribute__((swift_name("serialize(encoder:obj:)")));
@property (readonly) id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MetadataQueryUnitChildSerializer")))
@interface LoginModuleMetadataQueryUnitChildSerializer : KotlinBase <LoginModuleKotlinx_serialization_runtimeKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)metadataQueryUnitChildSerializer __attribute__((swift_name("init()")));
- (LoginModuleMetadataQueryUnitChild *)deserializeDecoder:(id<LoginModuleKotlinx_serialization_runtimeDecoder>)input __attribute__((swift_name("deserialize(decoder:)")));
- (LoginModuleMetadataQueryUnitChild *)patchDecoder:(id<LoginModuleKotlinx_serialization_runtimeDecoder>)decoder old:(LoginModuleMetadataQueryUnitChild *)old __attribute__((swift_name("patch(decoder:old:)")));
- (void)serializeEncoder:(id<LoginModuleKotlinx_serialization_runtimeEncoder>)output obj:(LoginModuleMetadataQueryUnitChild *)obj __attribute__((swift_name("serialize(encoder:obj:)")));
@property (readonly) id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CryptoUtilService")))
@interface LoginModuleCryptoUtilService : KotlinBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)md5Input:(NSString *)input __attribute__((swift_name("md5(input:)")));
@end;

__attribute__((swift_name("GKMALBOTPService")))
@protocol LoginModuleGKMALBOTPService
@required
- (LoginModuleRxcommon_coreSingle *)sendOTPRequestGenerateOTPTData:(id<LoginModuleGKMALBGenerateOTPTData>)generateOTPTData __attribute__((swift_name("sendOTPRequest(generateOTPTData:)")));
- (LoginModuleRxcommon_coreSingle *)sendOTPRequestPhoneNumber:(NSString *)phoneNumber __attribute__((swift_name("sendOTPRequest(phoneNumber:)")));
- (LoginModuleRxcommon_coreSingle *)validateOTPValidateOTPTData:(id<LoginModuleGKMALBValidateOTPTData>)validateOTPTData __attribute__((swift_name("validateOTP(validateOTPTData:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ExternalOTPService")))
@interface LoginModuleExternalOTPService : KotlinBase <LoginModuleGKMALBOTPService>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LoginModuleRxcommon_coreSingle *)sendOTPRequestGenerateOTPTData:(id<LoginModuleGKMALBGenerateOTPTData>)generateOTPTData __attribute__((swift_name("sendOTPRequest(generateOTPTData:)")));
- (LoginModuleRxcommon_coreSingle *)sendOTPRequestPhoneNumber:(NSString *)phoneNumber __attribute__((swift_name("sendOTPRequest(phoneNumber:)")));
- (LoginModuleRxcommon_coreSingle *)validateOTPValidateOTPTData:(id<LoginModuleGKMALBValidateOTPTData>)validateOTPTData __attribute__((swift_name("validateOTP(validateOTPTData:)")));
@end;

__attribute__((swift_name("GKMALBValidateAuthenticationDataService")))
@protocol LoginModuleGKMALBValidateAuthenticationDataService
@required
- (LoginModuleRxcommon_coreSingle *)validateUser:(NSString *)user password:(NSString *)password newPassword:(NSString * _Nullable)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validate(user:password:newPassword:device:)")));
- (LoginModuleRxcommon_coreSingle *)validateChangePasswordPreviousPassword:(NSString *)previousPassword newPassword:(NSString *)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validateChangePassword(previousPassword:newPassword:device:)")));
- (LoginModuleRxcommon_coreSingle *)validateConfirmForgotPasswordUsername:(NSString *)username password:(NSString *)password confirmationCode:(NSString *)confirmationCode __attribute__((swift_name("validateConfirmForgotPassword(username:password:confirmationCode:)")));
- (LoginModuleRxcommon_coreSingle *)validateCreateDeviceDeviceId:(NSString *)deviceId model:(NSString *)model type:(NSString *)type __attribute__((swift_name("validateCreateDevice(deviceId:model:type:)")));
- (LoginModuleRxcommon_coreSingle *)validateCreateNIPNipData:(id<LoginModuleGKMALBNIPData>)nipData __attribute__((swift_name("validateCreateNIP(nipData:)")));
- (LoginModuleRxcommon_coreSingle *)validateCreateUserName:(NSString * _Nullable)name fathersName:(NSString * _Nullable)fathersName mothersName:(NSString * _Nullable)mothersName emailAddress:(NSString * _Nullable)emailAddress phoneNumber:(NSString * _Nullable)phoneNumber device:(id<LoginModuleGKMALBDeviceData> _Nullable)device password:(NSString * _Nullable)password username:(NSString * _Nullable)username confirmationCode:(NSString * _Nullable)confirmationCode terms:(NSString * _Nullable)terms __attribute__((swift_name("validateCreateUser(name:fathersName:mothersName:emailAddress:phoneNumber:device:password:username:confirmationCode:terms:)")));
- (LoginModuleRxcommon_coreSingle *)validateForgotPasswordUsername:(NSString *)username question:(NSString * _Nullable)question answer:(NSString * _Nullable)answer __attribute__((swift_name("validateForgotPassword(username:question:answer:)")));
- (LoginModuleRxcommon_coreSingle *)validateGetTokenDevice:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validateGetToken(device:)")));
- (LoginModuleRxcommon_coreSingle *)validateLogoutDevice:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validateLogout(device:)")));
- (LoginModuleRxcommon_coreSingle *)validateMetadataUsername:(NSString *)username key:(NSString *)key value:(NSString *)value __attribute__((swift_name("validateMetadata(username:key:value:)")));
- (LoginModuleRxcommon_coreSingle *)validateMetadataQueryKeyDokId:(NSString *)keyDokId key:(NSString * _Nullable)key __attribute__((swift_name("validateMetadataQuery(keyDokId:key:)")));
- (LoginModuleRxcommon_coreSingle *)validateOTPTResponseValidateOTPTData:(id<LoginModuleGKMALBValidateOTPTData>)validateOTPTData validateOTPTResponse:(id<LoginModuleGKMALBValidateOTPTResponse>)validateOTPTResponse __attribute__((swift_name("validateOTPTResponse(validateOTPTData:validateOTPTResponse:)")));
- (LoginModuleRxcommon_coreSingle *)validateProfileProfile:(id<LoginModuleGKMALBProfileData>)profile __attribute__((swift_name("validateProfile(profile:)")));
- (LoginModuleRxcommon_coreSingle *)validateSendVerificationCodeUsername:(NSString *)username __attribute__((swift_name("validateSendVerificationCode(username:)")));
- (LoginModuleRxcommon_coreSingle *)validateValidateNIPValidateNIPData:(id<LoginModuleGKMALBValidateNIPData>)validateNIPData __attribute__((swift_name("validateValidateNIP(validateNIPData:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JsonSchemaValidateAuthenticationDataServiceBr")))
@interface LoginModuleJsonSchemaValidateAuthenticationDataServiceBr : KotlinBase <LoginModuleGKMALBValidateAuthenticationDataService>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LoginModuleRxcommon_coreSingle *)validateUser:(NSString *)user password:(NSString *)password newPassword:(NSString * _Nullable)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validate(user:password:newPassword:device:)")));
- (LoginModuleRxcommon_coreSingle *)validateChangePasswordPreviousPassword:(NSString *)previousPassword newPassword:(NSString *)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validateChangePassword(previousPassword:newPassword:device:)")));
- (LoginModuleRxcommon_coreSingle *)validateConfirmForgotPasswordUsername:(NSString *)username password:(NSString *)password confirmationCode:(NSString *)confirmationCode __attribute__((swift_name("validateConfirmForgotPassword(username:password:confirmationCode:)")));
- (LoginModuleRxcommon_coreSingle *)validateCreateDeviceDeviceId:(NSString *)deviceId model:(NSString *)model type:(NSString *)type __attribute__((swift_name("validateCreateDevice(deviceId:model:type:)")));
- (LoginModuleRxcommon_coreSingle *)validateCreateNIPNipData:(id<LoginModuleGKMALBNIPData>)nipData __attribute__((swift_name("validateCreateNIP(nipData:)")));
- (LoginModuleRxcommon_coreSingle *)validateCreateUserName:(NSString * _Nullable)name fathersName:(NSString * _Nullable)fathersName mothersName:(NSString * _Nullable)mothersName emailAddress:(NSString * _Nullable)emailAddress phoneNumber:(NSString * _Nullable)phoneNumber device:(id<LoginModuleGKMALBDeviceData> _Nullable)device password:(NSString * _Nullable)password username:(NSString * _Nullable)username confirmationCode:(NSString * _Nullable)confirmationCode terms:(NSString * _Nullable)terms __attribute__((swift_name("validateCreateUser(name:fathersName:mothersName:emailAddress:phoneNumber:device:password:username:confirmationCode:terms:)")));
- (LoginModuleRxcommon_coreSingle *)validateForgotPasswordUsername:(NSString *)username question:(NSString * _Nullable)question answer:(NSString * _Nullable)answer __attribute__((swift_name("validateForgotPassword(username:question:answer:)")));
- (LoginModuleRxcommon_coreSingle *)validateGetTokenDevice:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validateGetToken(device:)")));
- (LoginModuleRxcommon_coreSingle *)validateLogoutDevice:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validateLogout(device:)")));
- (LoginModuleRxcommon_coreSingle *)validateMetadataUsername:(NSString *)username key:(NSString *)key value:(NSString *)value __attribute__((swift_name("validateMetadata(username:key:value:)")));
- (LoginModuleRxcommon_coreSingle *)validateMetadataQueryKeyDokId:(NSString *)keyDokId key:(NSString * _Nullable)key __attribute__((swift_name("validateMetadataQuery(keyDokId:key:)")));
- (LoginModuleRxcommon_coreSingle *)validateOTPTResponseValidateOTPTData:(id<LoginModuleGKMALBValidateOTPTData>)validateOTPTData validateOTPTResponse:(id<LoginModuleGKMALBValidateOTPTResponse>)validateOTPTResponse __attribute__((swift_name("validateOTPTResponse(validateOTPTData:validateOTPTResponse:)")));
- (LoginModuleRxcommon_coreSingle *)validateProfileProfile:(id<LoginModuleGKMALBProfileData>)profile __attribute__((swift_name("validateProfile(profile:)")));
- (LoginModuleRxcommon_coreSingle *)validateSendVerificationCodeUsername:(NSString *)username __attribute__((swift_name("validateSendVerificationCode(username:)")));
- (LoginModuleRxcommon_coreSingle *)validateValidateNIPValidateNIPData:(id<LoginModuleGKMALBValidateNIPData>)validateNIPData __attribute__((swift_name("validateValidateNIP(validateNIPData:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("JsonSchemaValidateAuthenticationDataServiceMx")))
@interface LoginModuleJsonSchemaValidateAuthenticationDataServiceMx : KotlinBase <LoginModuleGKMALBValidateAuthenticationDataService>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LoginModuleRxcommon_coreSingle *)validateUser:(NSString *)user password:(NSString *)password newPassword:(NSString * _Nullable)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validate(user:password:newPassword:device:)")));
- (LoginModuleRxcommon_coreSingle *)validateChangePasswordPreviousPassword:(NSString *)previousPassword newPassword:(NSString *)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validateChangePassword(previousPassword:newPassword:device:)")));
- (LoginModuleRxcommon_coreSingle *)validateConfirmForgotPasswordUsername:(NSString *)username password:(NSString *)password confirmationCode:(NSString *)confirmationCode __attribute__((swift_name("validateConfirmForgotPassword(username:password:confirmationCode:)")));
- (LoginModuleRxcommon_coreSingle *)validateCreateDeviceDeviceId:(NSString *)deviceId model:(NSString *)model type:(NSString *)type __attribute__((swift_name("validateCreateDevice(deviceId:model:type:)")));
- (LoginModuleRxcommon_coreSingle *)validateCreateNIPNipData:(id<LoginModuleGKMALBNIPData>)nipData __attribute__((swift_name("validateCreateNIP(nipData:)")));
- (LoginModuleRxcommon_coreSingle *)validateCreateUserName:(NSString * _Nullable)name fathersName:(NSString * _Nullable)fathersName mothersName:(NSString * _Nullable)mothersName emailAddress:(NSString * _Nullable)emailAddress phoneNumber:(NSString * _Nullable)phoneNumber device:(id<LoginModuleGKMALBDeviceData> _Nullable)device password:(NSString * _Nullable)password username:(NSString * _Nullable)username confirmationCode:(NSString * _Nullable)confirmationCode terms:(NSString * _Nullable)terms __attribute__((swift_name("validateCreateUser(name:fathersName:mothersName:emailAddress:phoneNumber:device:password:username:confirmationCode:terms:)")));
- (LoginModuleRxcommon_coreSingle *)validateForgotPasswordUsername:(NSString *)username question:(NSString * _Nullable)question answer:(NSString * _Nullable)answer __attribute__((swift_name("validateForgotPassword(username:question:answer:)")));
- (LoginModuleRxcommon_coreSingle *)validateGetTokenDevice:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validateGetToken(device:)")));
- (LoginModuleRxcommon_coreSingle *)validateLogoutDevice:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("validateLogout(device:)")));
- (LoginModuleRxcommon_coreSingle *)validateMetadataUsername:(NSString *)username key:(NSString *)key value:(NSString *)value __attribute__((swift_name("validateMetadata(username:key:value:)")));
- (LoginModuleRxcommon_coreSingle *)validateMetadataQueryKeyDokId:(NSString *)keyDokId key:(NSString * _Nullable)key __attribute__((swift_name("validateMetadataQuery(keyDokId:key:)")));
- (LoginModuleRxcommon_coreSingle *)validateOTPTResponseValidateOTPTData:(id<LoginModuleGKMALBValidateOTPTData>)validateOTPTData validateOTPTResponse:(id<LoginModuleGKMALBValidateOTPTResponse>)validateOTPTResponse __attribute__((swift_name("validateOTPTResponse(validateOTPTData:validateOTPTResponse:)")));
- (LoginModuleRxcommon_coreSingle *)validateProfileProfile:(id<LoginModuleGKMALBProfileData>)profile __attribute__((swift_name("validateProfile(profile:)")));
- (LoginModuleRxcommon_coreSingle *)validateSendVerificationCodeUsername:(NSString *)username __attribute__((swift_name("validateSendVerificationCode(username:)")));
- (LoginModuleRxcommon_coreSingle *)validateValidateNIPValidateNIPData:(id<LoginModuleGKMALBValidateNIPData>)validateNIPData __attribute__((swift_name("validateValidateNIP(validateNIPData:)")));
@end;

__attribute__((swift_name("GKMALBAuthenticateService")))
@protocol LoginModuleGKMALBAuthenticateService
@required
- (LoginModuleRxcommon_coreSingle *)addMetadataToProfileUsername:(NSString *)username key:(NSString *)key value:(NSString *)value tokenData:(id<LoginModuleGKMALBTokenData> _Nullable)tokenData __attribute__((swift_name("addMetadataToProfile(username:key:value:tokenData:)")));
- (LoginModuleRxcommon_coreSingle *)changePasswordPreviousPassword:(NSString *)previousPassword newPassword:(NSString *)newPassword tokenData:(id<LoginModuleGKMALBTokenData>)tokenData device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("changePassword(previousPassword:newPassword:tokenData:device:)")));
- (LoginModuleRxcommon_coreSingle *)confirmForgotPasswordUsername:(NSString *)username password:(NSString *)password confirmationCode:(NSString *)confirmationCode __attribute__((swift_name("confirmForgotPassword(username:password:confirmationCode:)")));
- (LoginModuleRxcommon_coreSingle *)createDeviceDeviceId:(NSString *)deviceId model:(NSString *)model keyDokId:(NSString *)keyDokId type:(NSString *)type active:(BOOL)active __attribute__((swift_name("createDevice(deviceId:model:keyDokId:type:active:)")));
- (LoginModuleRxcommon_coreSingle *)createNIPNipData:(id<LoginModuleGKMALBNIPData>)nipData tokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("createNIP(nipData:tokenData:)")));
- (LoginModuleRxcommon_coreSingle *)createProfileProfile:(id<LoginModuleGKMALBProfileData>)profile __attribute__((swift_name("createProfile(profile:)")));
- (LoginModuleRxcommon_coreSingle *)createUserName:(NSString * _Nullable)name fathersName:(NSString * _Nullable)fathersName mothersName:(NSString * _Nullable)mothersName emailAddress:(NSString * _Nullable)emailAddress phoneNumber:(NSString * _Nullable)phoneNumber device:(id<LoginModuleGKMALBDeviceData> _Nullable)device password:(NSString * _Nullable)password username:(NSString * _Nullable)username confirmationCode:(NSString * _Nullable)confirmationCode terms:(NSString * _Nullable)terms __attribute__((swift_name("createUser(name:fathersName:mothersName:emailAddress:phoneNumber:device:password:username:confirmationCode:terms:)")));
- (LoginModuleRxcommon_coreSingle *)forgotPasswordUsername:(NSString *)username question:(NSString * _Nullable)question answer:(NSString * _Nullable)answer __attribute__((swift_name("forgotPassword(username:question:answer:)")));
- (LoginModuleRxcommon_coreSingle *)loginUser:(NSString *)user password:(NSString *)password newPassword:(NSString * _Nullable)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("login(user:password:newPassword:device:)")));
- (LoginModuleRxcommon_coreSingle *)logoutTokenData:(id<LoginModuleGKMALBTokenData>)tokenData device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("logout(tokenData:device:)")));
- (LoginModuleRxcommon_coreSingle *)queryMetadataFromProfileKeyDokId:(NSString *)keyDokId key:(NSString * _Nullable)key tokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("queryMetadataFromProfile(keyDokId:key:tokenData:)")));
- (LoginModuleRxcommon_coreSingle *)refreshTokenTokenData:(id<LoginModuleGKMALBTokenData>)tokenData device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("refreshToken(tokenData:device:)")));
- (LoginModuleRxcommon_coreSingle *)sendVerificationCodeUsername:(NSString *)username __attribute__((swift_name("sendVerificationCode(username:)")));
- (LoginModuleRxcommon_coreSingle *)userInfoTokenData:(id<LoginModuleGKMALBTokenData>)tokenData complete:(BOOL)complete __attribute__((swift_name("userInfo(tokenData:complete:)")));
- (LoginModuleRxcommon_coreSingle *)validateNIPValidateNIPData:(id<LoginModuleGKMALBValidateNIPData>)validateNIPData tokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("validateNIP(validateNIPData:tokenData:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KeyDokAuthenticateService")))
@interface LoginModuleKeyDokAuthenticateService : KotlinBase <LoginModuleGKMALBAuthenticateService>
- (instancetype)initWithBaseUrl:(NSString *)baseUrl __attribute__((swift_name("init(baseUrl:)"))) __attribute__((objc_designated_initializer));
- (LoginModuleRxcommon_coreSingle *)addMetadataToProfileUsername:(NSString *)username key:(NSString *)key value:(NSString *)value tokenData:(id<LoginModuleGKMALBTokenData> _Nullable)tokenData __attribute__((swift_name("addMetadataToProfile(username:key:value:tokenData:)")));
- (LoginModuleRxcommon_coreSingle *)changePasswordPreviousPassword:(NSString *)previousPassword newPassword:(NSString *)newPassword tokenData:(id<LoginModuleGKMALBTokenData>)tokenData device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("changePassword(previousPassword:newPassword:tokenData:device:)")));
- (LoginModuleRxcommon_coreSingle *)confirmForgotPasswordUsername:(NSString *)username password:(NSString *)password confirmationCode:(NSString *)confirmationCode __attribute__((swift_name("confirmForgotPassword(username:password:confirmationCode:)")));
- (LoginModuleRxcommon_coreSingle *)createDeviceDeviceId:(NSString *)deviceId model:(NSString *)model keyDokId:(NSString *)keyDokId type:(NSString *)type active:(BOOL)active __attribute__((swift_name("createDevice(deviceId:model:keyDokId:type:active:)")));
- (LoginModuleRxcommon_coreSingle *)createNIPNipData:(id<LoginModuleGKMALBNIPData>)nipData tokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("createNIP(nipData:tokenData:)")));
- (LoginModuleRxcommon_coreSingle *)createProfileProfile:(id<LoginModuleGKMALBProfileData>)profile __attribute__((swift_name("createProfile(profile:)")));
- (LoginModuleRxcommon_coreSingle *)createUserName:(NSString * _Nullable)name fathersName:(NSString * _Nullable)fathersName mothersName:(NSString * _Nullable)mothersName emailAddress:(NSString * _Nullable)emailAddress phoneNumber:(NSString * _Nullable)phoneNumber device:(id<LoginModuleGKMALBDeviceData> _Nullable)device password:(NSString * _Nullable)password username:(NSString * _Nullable)username confirmationCode:(NSString * _Nullable)confirmationCode terms:(NSString * _Nullable)terms __attribute__((swift_name("createUser(name:fathersName:mothersName:emailAddress:phoneNumber:device:password:username:confirmationCode:terms:)")));
- (LoginModuleRxcommon_coreSingle *)forgotPasswordUsername:(NSString *)username question:(NSString * _Nullable)question answer:(NSString * _Nullable)answer __attribute__((swift_name("forgotPassword(username:question:answer:)")));
- (LoginModuleRxcommon_coreSingle *)loginUser:(NSString *)user password:(NSString *)password newPassword:(NSString * _Nullable)newPassword device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("login(user:password:newPassword:device:)")));
- (LoginModuleRxcommon_coreSingle *)logoutTokenData:(id<LoginModuleGKMALBTokenData>)tokenData device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("logout(tokenData:device:)")));
- (LoginModuleRxcommon_coreSingle *)queryMetadataFromProfileKeyDokId:(NSString *)keyDokId key:(NSString * _Nullable)key tokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("queryMetadataFromProfile(keyDokId:key:tokenData:)")));
- (LoginModuleRxcommon_coreSingle *)refreshTokenTokenData:(id<LoginModuleGKMALBTokenData>)tokenData device:(id<LoginModuleGKMALBDeviceData> _Nullable)device __attribute__((swift_name("refreshToken(tokenData:device:)")));
- (LoginModuleRxcommon_coreSingle *)sendVerificationCodeUsername:(NSString *)username __attribute__((swift_name("sendVerificationCode(username:)")));
- (LoginModuleRxcommon_coreSingle *)userInfoTokenData:(id<LoginModuleGKMALBTokenData>)tokenData complete:(BOOL)complete __attribute__((swift_name("userInfo(tokenData:complete:)")));
- (LoginModuleRxcommon_coreSingle *)validateNIPValidateNIPData:(id<LoginModuleGKMALBValidateNIPData>)validateNIPData tokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("validateNIP(validateNIPData:tokenData:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KeyDokDateUtilService")))
@interface LoginModuleKeyDokDateUtilService : KotlinBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (BOOL)isDateExpiredMillisecons:(NSString *)millisecons __attribute__((swift_name("isDateExpired(millisecons:)")));
@end;

__attribute__((swift_name("GKMALBEventBusClientService")))
@protocol LoginModuleGKMALBEventBusClientService
@required
- (LoginModuleRxcommon_coreSingle *)getToken __attribute__((swift_name("getToken()")));
- (BOOL)initializeRepository __attribute__((swift_name("initializeRepository()")));
- (BOOL)removeToken __attribute__((swift_name("removeToken()")));
- (BOOL)saveTokenTokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("saveToken(tokenData:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KeyDokEventBusClientService")))
@interface LoginModuleKeyDokEventBusClientService : KotlinBase <LoginModuleGKMALBEventBusClientService>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LoginModuleRxcommon_coreSingle *)getToken __attribute__((swift_name("getToken()")));
- (BOOL)initializeRepository __attribute__((swift_name("initializeRepository()")));
- (BOOL)removeToken __attribute__((swift_name("removeToken()")));
- (BOOL)saveTokenTokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("saveToken(tokenData:)")));
@end;

__attribute__((swift_name("GKMALBJWTService")))
@protocol LoginModuleGKMALBJWTService
@required
- (LoginModuleRxcommon_coreSingle *)decryptToken:(id<LoginModuleGKMALBTokenData>)token __attribute__((swift_name("decrypt(token:)")));
- (LoginModuleRxcommon_coreSingle *)getActTimeToken:(id<LoginModuleGKMALBTokenData>)token __attribute__((swift_name("getActTime(token:)")));
- (LoginModuleRxcommon_coreSingle *)getKeyDokIdUserInfo:(NSString *)userInfo __attribute__((swift_name("getKeyDokId(userInfo:)")));
- (LoginModuleRxcommon_coreSingle *)getProfileFromStringUserInfo:(NSString *)userInfo __attribute__((swift_name("getProfileFromString(userInfo:)")));
- (LoginModuleRxcommon_coreSingle *)getUsernameToken:(id<LoginModuleGKMALBTokenData>)token __attribute__((swift_name("getUsername(token:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KeyDokJWTService")))
@interface LoginModuleKeyDokJWTService : KotlinBase <LoginModuleGKMALBJWTService>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LoginModuleRxcommon_coreSingle *)decryptToken:(id<LoginModuleGKMALBTokenData>)token __attribute__((swift_name("decrypt(token:)")));
- (LoginModuleRxcommon_coreSingle *)getActTimeToken:(id<LoginModuleGKMALBTokenData>)token __attribute__((swift_name("getActTime(token:)")));
- (LoginModuleRxcommon_coreSingle *)getKeyDokIdUserInfo:(NSString *)userInfo __attribute__((swift_name("getKeyDokId(userInfo:)")));
- (LoginModuleRxcommon_coreSingle *)getProfileFromStringUserInfo:(NSString *)userInfo __attribute__((swift_name("getProfileFromString(userInfo:)")));
- (LoginModuleRxcommon_coreSingle *)getUsernameToken:(id<LoginModuleGKMALBTokenData>)token __attribute__((swift_name("getUsername(token:)")));
@end;

__attribute__((swift_name("GKMALBTokenManagementService")))
@protocol LoginModuleGKMALBTokenManagementService
@required
- (LoginModuleRxcommon_coreSingle *)getToken __attribute__((swift_name("getToken()")));
- (BOOL)isTokenExpiredTokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("isTokenExpired(tokenData:)")));
- (BOOL)removeToken __attribute__((swift_name("removeToken()")));
- (BOOL)saveTokenTokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("saveToken(tokenData:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KeyDokTokenManagementService")))
@interface LoginModuleKeyDokTokenManagementService : KotlinBase <LoginModuleGKMALBTokenManagementService>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)keyDokTokenManagementService __attribute__((swift_name("init()")));
- (LoginModuleRxcommon_coreSingle *)getToken __attribute__((swift_name("getToken()")));
- (BOOL)isTokenExpiredTokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("isTokenExpired(tokenData:)")));
- (BOOL)removeToken __attribute__((swift_name("removeToken()")));
- (BOOL)saveTokenTokenData:(id<LoginModuleGKMALBTokenData>)tokenData __attribute__((swift_name("saveToken(tokenData:)")));
@end;

__attribute__((swift_name("GKMALBStorageService")))
@protocol LoginModuleGKMALBStorageService
@required
- (LoginModuleRxcommon_coreSingle *)getStateIdState:(NSString *)idState __attribute__((swift_name("getState(idState:)")));
- (LoginModuleRxcommon_coreSingle *)setStateIdState:(NSString *)idState state:(NSString *)state __attribute__((swift_name("setState(idState:state:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocalStorageService")))
@interface LoginModuleLocalStorageService : KotlinBase <LoginModuleGKMALBStorageService>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LoginModuleRxcommon_coreSingle *)getStateIdState:(NSString *)idState __attribute__((swift_name("getState(idState:)")));
- (LoginModuleRxcommon_coreSingle *)setStateIdState:(NSString *)idState state:(NSString *)state __attribute__((swift_name("setState(idState:state:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginBadResponseManager")))
@interface LoginModuleLoginBadResponseManager : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loginBadResponseManager __attribute__((swift_name("init()")));
- (NSString *)getCauseErrorString:(NSString *)errorString __attribute__((swift_name("getCause(errorString:)")));
@end;

__attribute__((swift_name("GKMALBValidationServiceFactory")))
@protocol LoginModuleGKMALBValidationServiceFactory
@required
- (id<LoginModuleGKMALBValidateAuthenticationDataService>)getValidator __attribute__((swift_name("getValidator()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationFactory")))
@interface LoginModuleValidationFactory : KotlinBase <LoginModuleGKMALBValidationServiceFactory>
- (instancetype)initWithConfiguration:(LoginModuleGKMACGlobalKitConfiguration *)configuration __attribute__((swift_name("init(configuration:)"))) __attribute__((objc_designated_initializer));
- (id<LoginModuleGKMALBValidateAuthenticationDataService>)getValidator __attribute__((swift_name("getValidator()")));
@property (readonly) LoginModuleGKMACGlobalKitConfiguration *configuration __attribute__((swift_name("configuration")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidationFactory.Companion")))
@interface LoginModuleValidationFactoryCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (readonly) NSString *CONFIG_NAME __attribute__((swift_name("CONFIG_NAME")));
@property (readonly) NSString *ES_MX __attribute__((swift_name("ES_MX")));
@property (readonly) NSString *PT_BR __attribute__((swift_name("PT_BR")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RequestUtil")))
@interface LoginModuleRequestUtil : KotlinBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RequestUtil.Companion")))
@interface LoginModuleRequestUtilCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpSendRequest")))
@interface LoginModuleOtpSendRequest : KotlinBase
- (instancetype)initWithMsisdn:(NSString *)msisdn message:(NSString *)message __attribute__((swift_name("init(msisdn:message:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (LoginModuleOtpSendRequest *)doCopyMsisdn:(NSString *)msisdn message:(NSString *)message __attribute__((swift_name("doCopy(msisdn:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSString *msisdn __attribute__((swift_name("msisdn")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpSendRequest.Companion")))
@interface LoginModuleOtpSendRequestCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpValidateRequest")))
@interface LoginModuleOtpValidateRequest : KotlinBase
- (instancetype)initWithToken:(LoginModuleTokenValidation *)token __attribute__((swift_name("init(token:)"))) __attribute__((objc_designated_initializer));
- (LoginModuleTokenValidation *)component1 __attribute__((swift_name("component1()")));
- (LoginModuleOtpValidateRequest *)doCopyToken:(LoginModuleTokenValidation *)token __attribute__((swift_name("doCopy(token:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LoginModuleTokenValidation *token __attribute__((swift_name("token")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpValidateRequest.Companion")))
@interface LoginModuleOtpValidateRequestCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenValidation")))
@interface LoginModuleTokenValidation : KotlinBase
- (instancetype)initWithKey:(NSString *)key value:(NSString *)value __attribute__((swift_name("init(key:value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (LoginModuleTokenValidation *)doCopyKey:(NSString *)key value:(NSString *)value __attribute__((swift_name("doCopy(key:value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@property NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenValidation.Companion")))
@interface LoginModuleTokenValidationCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpSendResponse")))
@interface LoginModuleOtpSendResponse : KotlinBase
- (instancetype)initWithToken:(LoginModuleToken *)token recipient:(LoginModuleRecipient *)recipient messageId:(NSString *)messageId __attribute__((swift_name("init(token:recipient:messageId:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *messageId __attribute__((swift_name("messageId")));
@property (readonly) LoginModuleRecipient *recipient __attribute__((swift_name("recipient")));
@property (readonly) LoginModuleToken *token __attribute__((swift_name("token")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpSendResponse.Companion")))
@interface LoginModuleOtpSendResponseCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpValidateResponse")))
@interface LoginModuleOtpValidateResponse : KotlinBase
- (instancetype)initWithToken:(LoginModuleToken *)token __attribute__((swift_name("init(token:)"))) __attribute__((objc_designated_initializer));
- (LoginModuleToken *)component1 __attribute__((swift_name("component1()")));
- (LoginModuleOtpValidateResponse *)doCopyToken:(LoginModuleToken *)token __attribute__((swift_name("doCopy(token:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LoginModuleToken *token __attribute__((swift_name("token")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OtpValidateResponse.Companion")))
@interface LoginModuleOtpValidateResponseCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Recipient")))
@interface LoginModuleRecipient : KotlinBase
- (instancetype)initWithMsisdn:(NSString *)msisdn androidAppHash:(NSString *)androidAppHash __attribute__((swift_name("init(msisdn:androidAppHash:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (LoginModuleRecipient *)doCopyMsisdn:(NSString *)msisdn androidAppHash:(NSString *)androidAppHash __attribute__((swift_name("doCopy(msisdn:androidAppHash:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *androidAppHash __attribute__((swift_name("androidAppHash")));
@property (readonly) NSString *msisdn __attribute__((swift_name("msisdn")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Recipient.Companion")))
@interface LoginModuleRecipientCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Token")))
@interface LoginModuleToken : KotlinBase
- (instancetype)initWithKey:(NSString *)key length:(int32_t)length exp:(int64_t)exp __attribute__((swift_name("init(key:length:exp:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int64_t)component3 __attribute__((swift_name("component3()")));
- (LoginModuleToken *)doCopyKey:(NSString *)key length:(int32_t)length exp:(int64_t)exp __attribute__((swift_name("doCopy(key:length:exp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t exp __attribute__((swift_name("exp")));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@property (readonly) int32_t length __attribute__((swift_name("length")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Token.Companion")))
@interface LoginModuleTokenCompanion : KotlinBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface LoginModuleKotlinByteArray : KotlinBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(LoginModuleByte *(^)(LoginModuleInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (LoginModuleKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

@interface LoginModuleKotlinByteArray (Extensions)
- (LoginModuleKotlinByteArray *)decodeBase64 __attribute__((swift_name("decodeBase64()")));
- (NSString *)decodeBase64ToString __attribute__((swift_name("decodeBase64ToString()")));
- (LoginModuleKotlinByteArray *)encodeBase64 __attribute__((swift_name("encodeBase64()")));
- (NSString *)encodeBase64ToString __attribute__((swift_name("encodeBase64ToString()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Base64Kt")))
@interface LoginModuleBase64Kt : KotlinBase
+ (NSString *)decodeBase64:(NSString *)receiver __attribute__((swift_name("decodeBase64(_:)")));
+ (LoginModuleKotlinByteArray *)decodeBase64ToByteArray:(NSString *)receiver __attribute__((swift_name("decodeBase64ToByteArray(_:)")));
+ (LoginModuleKotlinByteArray *)encodeBase64ToByteArray:(NSString *)receiver __attribute__((swift_name("encodeBase64ToByteArray(_:)")));
+ (NSString *)encodeBase64ToString:(NSString *)receiver __attribute__((swift_name("encodeBase64ToString(_:)")));
@end;

__attribute__((swift_name("Rxcommon_coreSource")))
@protocol LoginModuleRxcommon_coreSource
@required
- (id<LoginModuleRxcommon_coreSource>)combineLatestOtherSource:(id<LoginModuleRxcommon_coreSource>)otherSource transform:(id _Nullable (^)(id _Nullable, id _Nullable))transform __attribute__((swift_name("combineLatest(otherSource:transform:)")));
- (id<LoginModuleRxcommon_coreSource>)doOnCompleteOnComplete:(void (^)(void))onComplete __attribute__((swift_name("doOnComplete(onComplete:)")));
- (id<LoginModuleRxcommon_coreSource>)doOnEachObserver:(id<LoginModuleRxcommon_coreObserver>)observer __attribute__((swift_name("doOnEach(observer:)")));
- (id<LoginModuleRxcommon_coreSource>)doOnErrorOnError:(void (^)(LoginModuleKotlinThrowable *))onError __attribute__((swift_name("doOnError(onError:)")));
- (id<LoginModuleRxcommon_coreSource>)doOnNextOnNext:(void (^)(id _Nullable))onNext __attribute__((swift_name("doOnNext(onNext:)")));
- (id<LoginModuleRxcommon_coreSource>)filterKeep:(LoginModuleBoolean *(^)(id _Nullable))keep __attribute__((swift_name("filter(keep:)")));
- (LoginModuleRxcommon_coreSingle *)first __attribute__((swift_name("first()")));
- (id<LoginModuleRxcommon_coreSource>)flatMapResolveAdditionalSource:(id<LoginModuleRxcommon_coreSource> (^)(id _Nullable))resolveAdditionalSource __attribute__((swift_name("flatMap(resolveAdditionalSource:)")));
- (id<LoginModuleRxcommon_coreSource>)mapTransform:(id _Nullable (^)(id _Nullable))transform __attribute__((swift_name("map(transform:)")));
- (LoginModuleRxcommon_coreOnErrorReturn *)onErrorReturnResolveNewSource:(id<LoginModuleRxcommon_coreSource> (^)(LoginModuleKotlinThrowable *))resolveNewSource __attribute__((swift_name("onErrorReturn(resolveNewSource:)")));
- (id<LoginModuleRxcommon_coreDisposable>)subscribeObserver:(id<LoginModuleRxcommon_coreObserver>)observer __attribute__((swift_name("subscribe(observer:)")));
- (id<LoginModuleRxcommon_coreSource>)switchMapResolveNewSource:(id<LoginModuleRxcommon_coreSource> (^)(id _Nullable))resolveNewSource __attribute__((swift_name("switchMap(resolveNewSource:)")));
- (LoginModuleRxcommon_coreSingle *)toSingle __attribute__((swift_name("toSingle()")));
@end;

__attribute__((swift_name("Rxcommon_coreSingle")))
@interface LoginModuleRxcommon_coreSingle : KotlinBase <LoginModuleRxcommon_coreSource>
- (instancetype)initWithCreateWithEmitter:(id<LoginModuleRxcommon_coreDisposable> (^)(LoginModuleRxcommon_coreSingleEmitter *))createWithEmitter __attribute__((swift_name("init(createWithEmitter:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithJust:(id _Nullable)just __attribute__((swift_name("init(just:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithError:(LoginModuleKotlinThrowable *)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<LoginModuleRxcommon_coreDisposable>)subscribeObserver:(id<LoginModuleRxcommon_coreObserver>)observer __attribute__((swift_name("subscribe(observer:)")));
@property (readonly) LoginModuleRxcommon_coreSingleEmitter *emitter __attribute__((swift_name("emitter")));
@end;

__attribute__((swift_name("KotlinThrowable")))
@interface LoginModuleKotlinThrowable : KotlinBase
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(LoginModuleKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(LoginModuleKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (LoginModuleKotlinArray *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) LoginModuleKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("Rxcommon_coreEmitter")))
@protocol LoginModuleRxcommon_coreEmitter
@required
- (void)addObserverObserver:(id<LoginModuleRxcommon_coreObserver>)observer __attribute__((swift_name("addObserver(observer:)")));
- (void)complete __attribute__((swift_name("complete()")));
- (void)nextValue:(id _Nullable)value __attribute__((swift_name("next(value:)")));
- (void)removeObserverObserver:(id<LoginModuleRxcommon_coreObserver>)observer __attribute__((swift_name("removeObserver(observer:)")));
- (void)terminateThrowable:(LoginModuleKotlinThrowable *)throwable __attribute__((swift_name("terminate(throwable:)")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) BOOL isDisposed __attribute__((swift_name("isDisposed")));
@property (readonly) BOOL isTerminated __attribute__((swift_name("isTerminated")));
@end;

__attribute__((swift_name("Rxcommon_coreColdEmitter")))
@interface LoginModuleRxcommon_coreColdEmitter : KotlinBase <LoginModuleRxcommon_coreEmitter>
- (instancetype)initWithDoOnDispose:(void (^)(void))doOnDispose __attribute__((swift_name("init(doOnDispose:)"))) __attribute__((objc_designated_initializer));
- (void)addObserverObserver:(id<LoginModuleRxcommon_coreObserver>)observer __attribute__((swift_name("addObserver(observer:)")));
- (void)complete __attribute__((swift_name("complete()")));
- (void)nextValue:(id _Nullable)value __attribute__((swift_name("next(value:)")));
- (void)removeObserverObserver:(id<LoginModuleRxcommon_coreObserver>)observer __attribute__((swift_name("removeObserver(observer:)")));
- (void)terminateThrowable:(LoginModuleKotlinThrowable *)throwable __attribute__((swift_name("terminate(throwable:)")));
@property (readonly) NSMutableArray<id<LoginModuleRxcommon_coreObserver>> *activeObservers __attribute__((swift_name("activeObservers")));
@property BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property BOOL isDisposed __attribute__((swift_name("isDisposed")));
@property BOOL isTerminated __attribute__((swift_name("isTerminated")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Rxcommon_coreSingleEmitter")))
@interface LoginModuleRxcommon_coreSingleEmitter : LoginModuleRxcommon_coreColdEmitter
- (instancetype)initWithDoOnDispose:(void (^)(void))doOnDispose __attribute__((swift_name("init(doOnDispose:)"))) __attribute__((objc_designated_initializer));
- (void)complete __attribute__((swift_name("complete()"))) __attribute__((unavailable("Only intended for internal use.")));
- (void)nextValue:(id _Nullable)value __attribute__((swift_name("next(value:)")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeEncoder")))
@protocol LoginModuleKotlinx_serialization_runtimeEncoder
@required
- (id<LoginModuleKotlinx_serialization_runtimeCompositeEncoder>)beginCollectionDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc collectionSize:(int32_t)collectionSize typeParams:(LoginModuleKotlinArray *)typeParams __attribute__((swift_name("beginCollection(desc:collectionSize:typeParams:)")));
- (id<LoginModuleKotlinx_serialization_runtimeCompositeEncoder>)beginStructureDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc typeParams:(LoginModuleKotlinArray *)typeParams __attribute__((swift_name("beginStructure(desc:typeParams:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescription:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)enumDescription ordinal:(int32_t)ordinal __attribute__((swift_name("encodeEnum(enumDescription:ordinal:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));
- (void)encodeNull __attribute__((swift_name("encodeNull()")));
- (void)encodeNullableSerializableValueSerializer:(id<LoginModuleKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<LoginModuleKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
- (void)encodeUnit __attribute__((swift_name("encodeUnit()")));
@property (readonly) id<LoginModuleKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialDescriptor")))
@protocol LoginModuleKotlinx_serialization_runtimeSerialDescriptor
@required
- (NSArray<id<LoginModuleKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (NSArray<id<LoginModuleKotlinAnnotation>> *)getEntityAnnotations __attribute__((swift_name("getEntityAnnotations()")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) LoginModuleKotlinx_serialization_runtimeSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDecoder")))
@protocol LoginModuleKotlinx_serialization_runtimeDecoder
@required
- (id<LoginModuleKotlinx_serialization_runtimeCompositeDecoder>)beginStructureDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc typeParams:(LoginModuleKotlinArray *)typeParams __attribute__((swift_name("beginStructure(desc:typeParams:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescription:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)enumDescription __attribute__((swift_name("decodeEnum(enumDescription:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));
- (LoginModuleKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<LoginModuleKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<LoginModuleKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
- (void)decodeUnit __attribute__((swift_name("decodeUnit()")));
- (id _Nullable)updateNullableSerializableValueDeserializer:(id<LoginModuleKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableValue(deserializer:old:)")));
- (id _Nullable)updateSerializableValueDeserializer:(id<LoginModuleKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableValue(deserializer:old:)")));
@property (readonly) id<LoginModuleKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) LoginModuleKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GKMACGlobalKitConfiguration")))
@interface LoginModuleGKMACGlobalKitConfiguration : KotlinBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)getConfigurationConfigName:(NSString *)configName __attribute__((swift_name("getConfiguration(configName:)")));
- (NSString *)getConfigurationConfigName:(NSString *)configName defaultValue:(NSString *)defaultValue __attribute__((swift_name("getConfiguration(configName:defaultValue:)")));
- (NSString *)getConfigurationContext:(NSString *)context configName:(NSString *)configName defaultValue:(NSString * _Nullable)defaultValue __attribute__((swift_name("getConfiguration(context:configName:defaultValue:)")));
@end;

__attribute__((swift_name("KotlinIterator")))
@protocol LoginModuleKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end;

__attribute__((swift_name("KotlinByteIterator")))
@interface LoginModuleKotlinByteIterator : KotlinBase <LoginModuleKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (LoginModuleByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end;

__attribute__((swift_name("Rxcommon_coreOperator")))
@interface LoginModuleRxcommon_coreOperator : KotlinBase <LoginModuleRxcommon_coreSource, LoginModuleRxcommon_coreObserver>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)onComplete __attribute__((swift_name("onComplete()")));
- (void)onErrorThrowable:(LoginModuleKotlinThrowable *)throwable __attribute__((swift_name("onError(throwable:)")));
- (void)onNextValue:(id _Nullable)value __attribute__((swift_name("onNext(value:)")));
@property (readonly) id<LoginModuleRxcommon_coreEmitter> emitter __attribute__((swift_name("emitter")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Rxcommon_coreOnErrorReturn")))
@interface LoginModuleRxcommon_coreOnErrorReturn : LoginModuleRxcommon_coreOperator
- (instancetype)initWithUpstream:(id<LoginModuleRxcommon_coreSource>)upstream onErrorResolveNewSource:(id<LoginModuleRxcommon_coreSource> (^)(LoginModuleKotlinThrowable *))onErrorResolveNewSource __attribute__((swift_name("init(upstream:onErrorResolveNewSource:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (id<LoginModuleRxcommon_coreDisposable>)subscribeObserver:(id<LoginModuleRxcommon_coreObserver>)observer __attribute__((swift_name("subscribe(observer:)")));
@property (readonly) id<LoginModuleRxcommon_coreEmitter> emitter __attribute__((swift_name("emitter")));
@end;

__attribute__((swift_name("Rxcommon_coreDisposable")))
@protocol LoginModuleRxcommon_coreDisposable
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface LoginModuleKotlinArray : KotlinBase
+ (instancetype)arrayWithSize:(int32_t)size init:(id _Nullable (^)(LoginModuleInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (id _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<LoginModuleKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(id _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeEncoder")))
@protocol LoginModuleKotlinx_serialization_runtimeCompositeEncoder
@required
- (void)encodeBooleanElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(desc:index:value:)")));
- (void)encodeByteElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(desc:index:value:)")));
- (void)encodeCharElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(desc:index:value:)")));
- (void)encodeDoubleElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(desc:index:value:)")));
- (void)encodeFloatElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(desc:index:value:)")));
- (void)encodeIntElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(desc:index:value:)")));
- (void)encodeLongElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(desc:index:value:)")));
- (void)encodeNonSerializableElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(id)value __attribute__((swift_name("encodeNonSerializableElement(desc:index:value:)")));
- (void)encodeNullableSerializableElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index serializer:(id<LoginModuleKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(desc:index:serializer:value:)")));
- (void)encodeSerializableElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index serializer:(id<LoginModuleKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(desc:index:serializer:value:)")));
- (void)encodeShortElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(desc:index:value:)")));
- (void)encodeStringElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(desc:index:value:)")));
- (void)encodeUnitElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("encodeUnitElement(desc:index:)")));
- (void)endStructureDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc __attribute__((swift_name("endStructure(desc:)")));
- (BOOL)shouldEncodeElementDefaultDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(desc:index:)")));
@property (readonly) id<LoginModuleKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModule")))
@protocol LoginModuleKotlinx_serialization_runtimeSerialModule
@required
- (void)dumpToCollector:(id<LoginModuleKotlinx_serialization_runtimeSerialModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer> _Nullable)getContextualKclass:(id<LoginModuleKotlinKClass>)kclass __attribute__((swift_name("getContextual(kclass:)")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<LoginModuleKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));
- (id<LoginModuleKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<LoginModuleKotlinKClass>)baseClass serializedClassName:(NSString *)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end;

__attribute__((swift_name("KotlinAnnotation")))
@protocol LoginModuleKotlinAnnotation
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialKind")))
@interface LoginModuleKotlinx_serialization_runtimeSerialKind : KotlinBase
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeDecoder")))
@protocol LoginModuleKotlinx_serialization_runtimeCompositeDecoder
@required
- (BOOL)decodeBooleanElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(desc:index:)")));
- (int8_t)decodeByteElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeByteElement(desc:index:)")));
- (unichar)decodeCharElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeCharElement(desc:index:)")));
- (int32_t)decodeCollectionSizeDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc __attribute__((swift_name("decodeCollectionSize(desc:)")));
- (double)decodeDoubleElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(desc:index:)")));
- (int32_t)decodeElementIndexDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc __attribute__((swift_name("decodeElementIndex(desc:)")));
- (float)decodeFloatElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeFloatElement(desc:index:)")));
- (int32_t)decodeIntElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeIntElement(desc:index:)")));
- (int64_t)decodeLongElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeLongElement(desc:index:)")));
- (id _Nullable)decodeNullableSerializableElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index deserializer:(id<LoginModuleKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableElement(desc:index:deserializer:)")));
- (id _Nullable)decodeSerializableElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index deserializer:(id<LoginModuleKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableElement(desc:index:deserializer:)")));
- (int16_t)decodeShortElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeShortElement(desc:index:)")));
- (NSString *)decodeStringElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeStringElement(desc:index:)")));
- (void)decodeUnitElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index __attribute__((swift_name("decodeUnitElement(desc:index:)")));
- (void)endStructureDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc __attribute__((swift_name("endStructure(desc:)")));
- (id _Nullable)updateNullableSerializableElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index deserializer:(id<LoginModuleKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableElement(desc:index:deserializer:old:)")));
- (id _Nullable)updateSerializableElementDesc:(id<LoginModuleKotlinx_serialization_runtimeSerialDescriptor>)desc index:(int32_t)index deserializer:(id<LoginModuleKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableElement(desc:index:deserializer:old:)")));
@property (readonly) id<LoginModuleKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) LoginModuleKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface LoginModuleKotlinNothing : KotlinBase
@end;

__attribute__((swift_name("KotlinComparable")))
@protocol LoginModuleKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinEnum")))
@interface LoginModuleKotlinEnum : KotlinBase <LoginModuleKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
- (int32_t)compareToOther:(LoginModuleKotlinEnum *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_runtimeUpdateMode")))
@interface LoginModuleKotlinx_serialization_runtimeUpdateMode : LoginModuleKotlinEnum
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) LoginModuleKotlinx_serialization_runtimeUpdateMode *banned __attribute__((swift_name("banned")));
@property (class, readonly) LoginModuleKotlinx_serialization_runtimeUpdateMode *overwrite __attribute__((swift_name("overwrite")));
@property (class, readonly) LoginModuleKotlinx_serialization_runtimeUpdateMode *update __attribute__((swift_name("update")));
- (int32_t)compareToOther:(LoginModuleKotlinx_serialization_runtimeUpdateMode *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModuleCollector")))
@protocol LoginModuleKotlinx_serialization_runtimeSerialModuleCollector
@required
- (void)contextualKClass:(id<LoginModuleKotlinKClass>)kClass serializer:(id<LoginModuleKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<LoginModuleKotlinKClass>)baseClass actualClass:(id<LoginModuleKotlinKClass>)actualClass actualSerializer:(id<LoginModuleKotlinx_serialization_runtimeKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
@end;

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol LoginModuleKotlinKDeclarationContainer
@required
@end;

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol LoginModuleKotlinKAnnotatedElement
@required
@end;

__attribute__((swift_name("KotlinKClassifier")))
@protocol LoginModuleKotlinKClassifier
@required
@end;

__attribute__((swift_name("KotlinKClass")))
@protocol LoginModuleKotlinKClass <LoginModuleKotlinKDeclarationContainer, LoginModuleKotlinKAnnotatedElement, LoginModuleKotlinKClassifier>
@required
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end;

#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
