//
//  SDKCoreBR.h
//  SDKCoreBR
//
//  Created by Lucio Couto on 10/09/20.
//  Copyright © 2020 Lucio Couto. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SDKCoreBR.
FOUNDATION_EXPORT double SDKCoreBRVersionNumber;

//! Project version string for SDKCoreBR.
FOUNDATION_EXPORT const unsigned char SDKCoreBRVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SDKCoreBR/PublicHeader.h>


