//
//  SDKCoreMX.h
//  SDKCoreMX
//
//  Created by Lucio Couto on 05/09/20.
//  Copyright © 2020 Lucio Couto. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SDKCoreMX.
FOUNDATION_EXPORT double SDKCoreMXVersionNumber;

//! Project version string for SDKCoreMX.
FOUNDATION_EXPORT const unsigned char SDKCoreMXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SDKCoreMX/PublicHeader.h>


